---
aliases: []
tags: [os] 
date: 2022-03-24
---
***
# Page allocation 
Hoe verdelen we het geheugen tussen processen? 
Dit is overigens anders dan [[#Kernel memory allocation]]. 

## Welke manieren van verdelen zijn er? 
*Pure demand paging*: bij het starten van een proces zijn alle pages vrij. 
*Equal allocation*: alle processen krijgen hetzelfde aantal pages. 
*Proportional allocation*: we verdelen pages aan processen gebaseerd op diens groottes. 

## Hoe kan je de prestaties van demand paging verbeteren?  
Als eerste kan je *prepaging* toepassen. Dit is het laden van de hele [[#Locality]] in één keer. Dit is handig bij het laden van bestanden, omdat die vaak sequentieel worden gelezen. 

Je moet ook nadenken over de optimale page size. 
- Groot: meer [[Contiguous memory allocation#^b91e60|internal fragmentation]], maar snellere I/O omdat seek time minder is. 
- Klein: grotere overhead voor opslaan van page tables, maar [[#Locality]] accuracy is beter. 

De [[Translation Look-aside Buffer]] kan geheugen bereiken gegeven door (# van TLB entries) $\times$ (entry page size). Het vergroten van de TLB entries is vaak niet haalbaar, dus moeten we maar voor grotere pages kiezen. 

# Locality in replacement
Dit gaat over uit welke set met pages een proces kan kiezen. 

## Wat is het verschil tussen global en local replacement? 
Bij *Global replacement* kan een proces uit alle pages kiezen, ook uit degenen die aan andere processen zijn gealloceerd. **Dit kan prestaties van andere processen beïnvloeden.** 
System throughput wordt verhoogd. Vaak gebruikt in combinatie met het bijhouden van een [[Page Replacement#Page buffering|pool van vrije pages]]. 

Bij *Local replacement* kan een proces alleen uit zijn eigen gealloceerde pages kiezen, zelfs als andere processen vrije pages hebben. 

# Thrashing 
Er kan thrashing ontstaan als een proces niet genoeg pages gealloceerd heeft gekregen. Er zijn manieren om dit te voorkomen: [[Thrashing and the working-set model]]. 

# Kernel memory allocation 
Dit is apart van user memory. Wel zo handig: 
- Kernel code heeft verschillende grootte pages nodig, wat [[Contiguous memory allocation#^b91e60|internal fragmentation]] kan veroorzaken. 
- Kernel pages wil je niet discarden 
- Kernel moet [[Contiguous memory allocation]] kunnen doen voor datastructuren zoals de [[Translation Look-aside Buffer]]. 

