---
aliases: [hard disk, hdd]
tags: [os] 
date: 2022-05-12
---
***
# Hard disk drives 
## Physical 
Consists of **spindle** with magnetic platters, and a moving arm with a reading head. 

## What are the (dis)advantages of a HDD?
Moving parts! 
- The spindle and arm move, shocks might cause *head crash*: the reading head hits the disks hard enough to be damaged. 
- **Data is physically distanced**, so moving to the data in order to r/w it costs time 

## How are HDDs connected? 
Connected to host controller through an *interface* such as 
- Current: SATA, SAS, USB
- Past: (E)IDE, SCSI, Firewire

## What determines the transfer rate?
The transfer rate is influenced by the *positioning time* (for random access) which consists of two components: 
- *Seek time*: moving the disk arm to the desired cylinder location. **Order of magnitude in milliseconds!**
- *Rotational latency*: time to wait before desired disk sector appears under the head. 


## How are disk address mapped physically to logically?
See [[Disk Address Mapping]]. 

## How can the OS improve effective performance of HDDs?
By choosing for a fitting choice of [[Hard Disk Scheduling]], impact of physical limitations such as seek time can be reduced. 