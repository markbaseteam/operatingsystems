---
aliases: [file organisation]
tags: [os] 
date: 2022-04-04
---
***
# File system organisation 
## Hoe is het file system van een disk ingedeeld? 
Een disk is eigenlijk een enkele lange byte string. 
We moeten dit organiseren. De OS kernel doet dit door attributen op te slaan samen met de inhoud (data) van bestanden, e.g. naam, grootte, permissions. Maar ook meer 'file-system-specific' attributen, zoals een *unique file system identifier* en de fysieke locatie op de disk. 

Verder gaat het over 
- [[Files in operating systems]] 
- [[Directories in operating systems]]
- [[Linking to files]] 
- [[Memory-mapped files]]

## Hoe worden files beschermd tegen onbevoegde toegang? 
Bij multi-user systemen moeten files worden beschermd tegen onbevoegde toegang. Dit kan door permissions op te slaan in de file attributes. 
