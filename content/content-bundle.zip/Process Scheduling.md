---
aliases: []
tags: [OS] 
date: 2022-02-28
---
***

# Scheduling
Stel je hebt 1 CPU, en meerdere processen in je lijst. Hoe bepaal je welk proces er CPU tijd krijgt?

Dit doet het OS aan de hand van het [[CPU scheduling algorithm]]. 

## Wat is het doel van het CPU scheduling algorithm?
Er is een bron (de CPU) waar we zo efficient mogelijk gebruik van willen maken. 

# Lijsten processen 
## Welke lijsten met processen worden door het OS bijgehouden?
In het OS zijn er vaak meerdere lijsten of queus om processesn op te slaan: 
- een lijst met alle taken in het systeem (de **job queue**)
- een queue van processen die klaar zijn om uitgevoerd te worden en dus niet blokkeren (**ready queue**)
- een queue per apparaat, met processen die wachten tot ze geserveerd worden (**device/wait queue**)
- een queue met processen die zichzelf hebben stopgezet (sleeping), die **wachten op een timer interrupt**. 

Processen bewegen tussen deze lijsten. 
Beslissingen over scheduling worden genomen op
 - waiting -> running 
 - running -> waiting 
 - running -> ready 
 - running -> terminate
![[process state transition.png|500]]

# Short-term schedulers 
De short-term CPU scheduler is bij alle timesharing systemen geimplementeerd. Hij wordt aangeroepen e.g. als het huidie process blokkeert, en het systeem wil weten welk volgend process moet worden uitgevoerd. 

Deze scheduler moet heel vaak (~ elke 100ms) een beslissing maken. 


# Long-term (job) scheduler
De long-term CPU scheduler is minder in gebruik. Deze bepaalt welke jobs in het geheugen moeten worden geladen en wanneer. 

Tegenwoordig enkel nog te vinden in cluster computers, waarbij programma's als batch jobs worden uitgevoerd. 

Deze batch jobs voeren heel lang (uren/weken/maanden) uit. Dus beslissingen hoeven niet vaak te worden gemaakt. 