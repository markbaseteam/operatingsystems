---
aliases: [file systems]
tags: [os] 
date: 2022-04-04
---
***

### OS metadata structures about the file system
When in operation, OS kernel also stores important info in the *main memory*: 
- ***mount table***: list of mounted (*opened*) files  
- in-memory **cache** of directory tree 
- ***open-file table*** (*system wide*): when a file is opened with `open()` syscall, corresponding FCB is stored in memory. 
	- ***file open count*** is maintained in here
- **open-file table** (*per process*): table containing reference to each file opened by the process, and the **r/w-pointer** for each of those files 

![[file system structures.png|400]]

## Identifying and opening file systems 
File system is **opened** when it is **mounted**
Mount call specifies only *device file* and *mount point*

OS then has to find out if given device does contain file system of given type: 
- file systems often have specific signature (known as **magic signature**), and autodetect can be done though DB containing those signatures 
- sometimes even explicitly provided by mount call 

Then OS reads and validates the metadata of the filesystem, its [[File organisation module#Superblock]]. 

## Opening files 
How? 
1. Send filename to logical file system. 
2. System-wide *open file table* is checked, to see if maybe another process has it open 
3. If not, search directory structure (parts not cached in main memory are retrieved from storage) 
4. Load the [[File Control Block]] into memory 
5. Add opened file to open file table of the process, and init the *r/w-pointer*
6. Return a *handle* to the entry in the open file table. Though this handle, file operations can be performed


![[file opening process visual.png|500]]


# Chapter 14 (contd.)

Above, we learned that to store a directory, we simply need a list of files and subdirectories (can be nested). 

Can be done in various ways. Simple linear list is easy to implement & manage. But **searching** requires linear scans, which is inefficient for large directories. 

Possible solutions: 
- caching directory contents in memory (VFS tree)
 #Todo/Onderzoeken  : wat is een vfs tree? 
   and maintain tree-based index. 


## Disk subsystem performance 
Techniques to improve disk dubsystem performance: 

**Buffering of disk blocks**: keep frequently used disk blocks in main memory (like *buffer cache* or *page cache*)

**Asynchonous writes**: tell application that does `write()` syscall that the operation has finished, but buffer the data to be written and write to disk later. **Some application require synchronous writes, because they are safer** (data is guaranteed to be written once syscall returns) ^3b60b0

**Read-ahead**: If the OS kernel detects sequential reading, it can read next blocks before it is acutally requested (and also blocks that have been read can be purged from buffer cache, *free-behind*)

# Chapter 15 
Not very clear structure, and only discuss: 
- File systems
- Disk partitions / volumes / devices 
- File system mounting 
- Virtual file systems 
- Remote file systems 

## File system 
File's contents and metadata need to be stored. Done in different formats, known as ***file systems*** like FAT, NTFS, HFS, ext{2,3,4}, xfs, zfs. 
File system also encodes directory structure; sometimes file attributes are stored as part of directory structure. 
Attributes of file system itself are stored in a [[Superblock]] at specific location within file system. 

## File systems on disks 
File system needs to be stored in contiguous area on disk. To create areas, a disk is divided into ***partitions***. These are stored in a ***partition table*** located at start of disk. Once partition is populated with file system, refer to it as ***volume***. 

Also possible to bundle multiple disks to form a single disk, e.g. using RAID (see ch. [[Mass Storage Structures]])

Disk partitions are not flexible: need to be contigious. How to solve? 
***Logical volume manager***, like Linux LVM. 
Disks are physical volumes, placed in **volume group**. Within volume group, ***logical volumes*** can be created. These may span multiple disks, and need not be contiguous. 
Volume manager then maintains mapping from logical to physical. 
Logical volume is always contiguous; requires a suitable storage to store file system on. 

# File system mounting
There can be multiple volumes. How to access files? 
UNIX and windows differ: 
- Windows: use drive letters 
- UNIX: **mounting** 

File system ***mounting***: mount file system at *mount point* (placeholder directory) to access. Different volumes can be placed in any depth of another tree: ![[Screenshot_20210412_115227.png|300]]

# Virtual file system 
**Lical file system layer** often structured as virtual file system. 

***Virtual file system*** **(VFS)**: object-oriented implementation: 'file' base class defining methods, then apps are programmed to use these generic calls. 
Other file system implementations then subclass the base class, and use their own methods. 
Now still a ==single tree, but files can be on different file systems==.

 Note: Linux written in C, not C++, so has to use plain C stucture `struct`, containing function pointers: 
  ``` C 
struct file_operations {
 	struct module *owner; 
	(*llseek) (struct file *, loff_t, int);
	ssize_t (*read) (struct file *, char __user *, size_t, loff_t *); 
// ...
 }
``` 

