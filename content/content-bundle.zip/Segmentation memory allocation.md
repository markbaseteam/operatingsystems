---
tags: [os]
aliases: []
date: 2022-03-15
---
***

# Segmentation 
## Wat is segmentation? 
Dit zit tussen contiguous allocation en paging in. 
Een proces heeft meerdere segmenten, die niet naast elkaar hoeven te liggen en allemaal een andere grootte kunnen hebben. Ze kunnen ook worden gedeeld onder processen. 

## Hoe is segmentation geïmplementeerd?
Geheugenadres wordt tuple $(\text{segment number, addres})$ waarbij het segment number een index is in een *segment table*. 

Bij een context-switch wordt de pointer naar de segment table veranderd. 