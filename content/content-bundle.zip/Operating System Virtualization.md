---
aliases: [virtual machines]
tags: [os] 
date: 2021-10-21
---
***
Allows OS to be executed as guest process in host OS. Services provided by the *Virtual Machine Manager (VMM)*. 

Widespread usage: cloud computing, data centers. 

Guest OS can be compiled for same architecture as host, so instructions run directly on CPU. If not, *emulation* takes place: the host must convert guest instructions to ones for its own architecture. 
***