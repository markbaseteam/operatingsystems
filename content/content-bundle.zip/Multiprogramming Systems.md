---
aliases: [Single user systems, Single program systems]
tags: [os] 
date: 2022-02-11
---
***
# Multiprogramming systems
Initially, computers were limited. 

## Simple operating systems
Only **single user and single process** (e.g. DOS) 

No efficient use of all available hardware resources; not possible to keep hardware busy all the time. 

## What are multiprogramming systems?
For more efficient use of hardware, use *multiprogramming* systems. 

Called '*batch systems*': queue of jobs processed in order; *job scheduler* determines next job to load into memory. When a job blocks on I/O, the system switches to non-blocking job. 

Later (more powerful computers) jobs could be interrupted with interactive jobs, e.g. debugging. 

### What is multitasking?
Later extended with *timesharing* — what we now know as *multitasking*. 
The CPU switches jobs rapidly, which makes it look as if multiple programs are run simultaneously. 
It allows for *interactive* programs, where the response time is less than one second. 

To run multiple processes at the same time that don't fit in memory, two techniques are used: [[Swapping]] and [[Virtual Memory]]. 

### What are the issues that appear when multiple programs run at the same time with no restrictions? 

When there are no restrictions on hardware and resources: 
- uncoordinated writes to drives
- interleaved writes to printers 
- active programs writing into each other's memory

There needs to be a single process in control, with more privileges than 'normal' processes. This is the *operating system kernel*. 

### What is the role of the OS kernel in interactive systems? 
The operating system serves to **control and isolate processes**. 
