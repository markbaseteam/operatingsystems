---
aliases: []
tags: [stub, os]
date: 2022-04-04
---
***
We kunnen ook [[Virtual Memory]] technieken gebruiken toegang tot files mogelijk te maken. 

**Een memory-mapped file is deel van de virtual address space van een proces.** In plaats van `read()`/`write()` gebruiken we nu gewoon load/store instructies — alsof we op geheugen aan het opereren zijn. 

Als een virtual page wordt aangesproken, bepaalt het OS het respectieve deel van de file en brengt deze naar geheugen (dit is [[Virtual Memory|Demand paging]]!). Op dezelfde manier worden alle aanpassingen weer teruggeschreven naar de disk. 

Het voordeel van deze techniek is dat geheugentoegang veel goedkoper is dan toegang tot secundaire opslag. Daarnaast kunnen bestanden nu worden gedeeld met meerdere processen door [[Copy-on-write]]. 
***