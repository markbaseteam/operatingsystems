---
aliases: [Introduction to Operating Systems, What is an operating system?]
tags: [os] 
date: 2021-05-31
---
# Operating system 
## What is an operating system?
> [!info] Definition: Operating system 
> “An operating system is software that manages a computer’s  
  hardware. It also provides a basis for application programs  
  and acts as an intermediary between the computer user and  
  the computer hardware.”

## Why use an operating system? 
**Convenient**: no separate drivers for every program 
**Efficient**: share available resources among users and programs 

# Structure 
![[schematic structure of operating systems.png|300]]
## What parts does a working computer consist of? 
**Hardware**: CPU, main memory, disk drives, network interface, etc. 
**Operating system**: manages and coordinates hardware, and provides abstracted interface to hardware. 
**Application programs**: running on top of the OS. 
**Users**: direct users of the system, but also connected users and other machines. 

## Which parts does an operating system usually consist of? 
- **Middleware** (mobile OS only): frameworks providing services to application programmers
- **Kernel**: executable, always loaded into main memory (in background) 
- **System programs**: help the kernel with managing hardware and programs 

# What are the main responsibilities of an operating system? 
**Resource allocation**: ensure efficient & fair use, and decide what to do if requests are in conflict. 
**Control & isolation**: Prevent users and programs from damaging the system. 

# Organization of computer systems 
The *north bridge* is responsible for the communication between the CPU and memory devices. It controls the external GPU and memory slots, and — through an internal bus — has access to the *south bridge*. 

The south bridge controls the I/O devices, including flash rom, external ports, and the integrated graphics controller. 

![[schematic overview of internal motherboard structure.png|400]]

# Startup
## What happens when a computer boots up? 
Three steps: 
1. *Bootstrap program* on ROM loads OS into main memory 
2. Kernel finishes initializing devices and internal data structures 
3. kernel sits idle until command
	- *interrupts* from devices, 
	- *exceptions* from software due to either errors or requests,
	- periodically checks connected devices through *polling*

## What is the difference between input through interrupts, and input through polling? 
Polling and interrupts work very different. 

In *interrupts*, devices interrupt the CPU. It then saves the current state, and enters *interrupt service routine (ISR)*. 
With *polling*, the CPU continually polls a device. 

Example: USB is *host-driven*; devices need to be polled by the USB host. The host then interrupts CPU if necessary

# Memory access 
## How can devices access memory? 
Many devices have a controller that can request the CPU for memory access. Nowadays [[Direct Memory Access]] is more common — the CPU now does not need to interfere to grant access to memory. 

# Storage
## What are the advantages and disadvantages of main and secondary storage?
Main storage: 
- random access 
- directly accessible by CPU 
- faster
- *volatile*: not saved when losing power 

Secondary storage:
- greater capacity 
- no direct access by CPU 
- slower
- *non-volatile*

See also [[Mass Storage Structures|lecture 10 on mass storage systems]]

# Caching 
Discussed in [[Computer Architecture]]: **caching is a generic concept**. 
It is applicable to disk block in RAM, flash cache in RAID systems, [[Page Cache]] in file systems, [[Translation Look-aside Buffer]] in paging,  etc.

