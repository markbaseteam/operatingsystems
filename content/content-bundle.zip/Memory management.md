---
aliases: []
tags: [os] 
date: 2022-03-15
---
***

# Memory management 
Hoe beslist het OS waar de data komt te staan die processen in het geheugen willen hebben?

# De geheugenmodule 
## Welke verantwoordelijkheden heeft de geheugenmodule?
De CPU heeft toegang tot het geheugen door load/store instructies. Geheugenmodules ontvangen deze requests voor bepaalde adressen. **Deze module weet de context niet**; het weet niet tot welke proces het geheugen behoort. Het gevolg is dat deze modules **niet de geheugenscheiding tussen processen kunnen afdwingen, dus dit moet in de CPU worden gedaan**. 

## Wat is de simpelste manier om geheugenbescherming te implementeren?
Een heel simpele implementatie van deze bescherming is door het gebruiken van **base en limit registers**. Deze geven het onderste en uiterste addres van het proces dat nu aan het uitvoeren is. Processen kunnen niet zelf bij deze registers, ze kunnen enkel worden gezet door de OS kernel. Voor **elke memory access die wordt gevraagd, checkt de CPU of het adres binnen deze registers valt**.  ^e3c18d

# Adress binding 
## Hoe worden instructies en data aan geheugenadressen verbonden?
[[Address binding]]: hoe instructies en data aan daadwerkelijke geheugenaddressen zijn verbonden. 
- *Absolute addressing* is niet relatief van het proces, maar **relatief ten opzichte van het fysieke geheugen**. Het gevolg is dat het programma altijd op precies dezelfde plek in het fysieke geheugen moet worden geladen. 
- *Relative addressing* is relatief ten opzichte van een bepaald adres in een register, of zo opgebouwd dat absolute adressen die een proces in geheugen requests gebruikt tijdens runtime kunnen worden aangepast. 

## Hoe verandert het addressing scheme tijdens het bouwen en uitvoeren van een programma?
Het adressing scheme verandert tijdens het bouwen van een programma: 
1. *Symbolic* in de source code, waarbij identifiers worden gebruikt die refereren naar geheugenlocaties
2. *Relocatable*: in object bestanden zijn relatieve adressen in gebruik, die later naar een andere fysieke locatie kunnen wijzen
3. *Executable*: in een non-relocatable executable zijn alle addressen absoluut. 

## Tijdens welke stappen kan address binding plaatsvinden?
Het volgt dat address binding op verschillende stages van het bouwen van een programma kan plaatsvinden: 
1. *Compile time*: in dit geval komt uit het compileren een executable die gelijk absolute adressen gebruikt. Als deze adressen veranderen, moet het hele programma opnieuw gecompileerd worden. 
2. *Load time*: als de locatie waar het programma gaat uitvoeren nog niet bekend is tijdens het compileren, kan het binden worden uitgesteld door relocatable code te genereren. Pas bij linking of loading worden deze relatieve adressen gereloceert. 
3. *Execution time*: het binden gebeurt pas tijdens het uitvoeren, dus tijdens run-time, als een geheugenlocatie wordt gerefereerd. 

## Kunnen we een programma verplaatsen?
Let op dat **een programma niet in het geheugen kan worden verplaatst als compile-time of load-time binding zijn gebruikt**. 
Bij execution-time binding is dit wel mogelijk, maar daar is **hardware support voor nodig**. De [[Memory Management Unit]] vertaalt adressen die het programma geeft naar fysieke adressen. Op deze manier hoeft het programma nooit worden aangepast. 
Hier ontstaat **het verschil tussen [[Virtual Memory|virtual/logical addresses]] en physical addresses**. 

## Wat is de simpelste manier om logical addressing te implementeren?
Een simpel schema voor de MMU om te vertalen is het gebruiken van het [[#^e3c18d|base register]] dat voor geheugenbescherming werd geïntroduceerd. 
We hernoemen het naar het *relocation* register, omdat we het vanaf nu gebruiken om te vertalen van een adres uit een programma naar een fysiek adres door de waarde in het register erbij op te tellen.  ^cce94a

***

## Welk gedeelte van een proces wordt in het geheugen geladen?
Het is niet altijd handig om het hele proces in het geheugen te laden — en soms zelfs niet mogelijk (als het proces groter is dan de beschikbare ruimte). 

We kunnen geheugenverbruik verminderen met twee technieken: 
- dynamic loading waarvoor geen OS support voor nodig is, 
- dynamic linking, waarbij het OS calls naar externe libraries moet kunnen afhandelen

## Wat is dynamic loading?
We kunnen kiezen om slechts een deel van het proces in te laden: [[Dynamic Loading]]. Hier blijven routines en data op de disk, zodat ze kunnen worden geladen (in relocatabel format) als het nodig is. Voor dynamic loading is geen OS support nodig, hoewel support in de vorm van een helper library het flink kan versimpelen. 

## Wat is dynamic linking?
Een andere techniek is [[Dynamic Linking]]: pas bij execution time. Dus linken gaat met libraries die tijdens het runnen van het programma zijn gevonden. Libraries kunnen worden geupdate zonder het programma te hoeven hercompileren. Bekend als *shared libaries*: DLL in Windows, .so in Unix, .dylib in macOS. 

### Hoe is dynamic linking geimplementeerd in een gecompileerd proces?
Hoe werkt dit? Tijdens compileren gaan calls naar nog niet bekende functies naar een *stub routine*. De eerste keer dat die functie is geroepen, gaat de stub routine de echte functie zoeken, en zodra dat is gelukt wordt de stub routine vervangen door de echte call. Als het niet lukt, dan komt er een exception. 

### Wat is het verschil tussen static en dynamic linking?
Contrast met [[Static linking]]: waarbij een uitvoerbaar bestand gecombineerd is met alle libraries tijdens load time. Er ontstaat dan een single binary image die alle dependencies bevat. 
