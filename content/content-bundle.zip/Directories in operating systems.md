---
aliases: [Directories, Directory structure]
tags: [os] 
date: 2022-04-04
---
***
# Directories 
## Wat is een directory? 
Een directory is een verzameling van bestanden in een groep, waar met de directory naam naar wordt verwezen. 

## Wat is de directory structure? 
Van een directory moeten we weten welke files deze bevat. Informatie over directories moet ook op de disk staan. Daarnaast moet een directory ondersteuning hebben voor bepaalde operaties: create/remove directory, list files, create/delete file, search for file. 

We moeten informatie over de directory structure opslaan. Enkele aspecten moeten worden overwogen: grouping, efficiency of file finding, uniquely naming files

## Welke typen directory structures bestaan er? 
### Single level directory structure
early systems had a single directory shared by all users. This does not allow grouping, and needs to enforce unique filenames across the entire system. 

### Two-level directory structure 
later, each user received their own directory, but grouping was still not supported. 

### Tree-structured directory directory structure
Met sub-directories is grouping supported. Zoeken is efficienter, omdat binnen kleinere directories moet worden gezocht. 
**File paths zijn nu essentieel**. 
1. Start bij de root "/"
2. Voeg directory components aan het pad toe tot je de doel directory bereikt 
3. Voeg filename toe aan pad 

Alle filenames starting with "/" zijn *absolute paths*, en de rest zijn *relative paths*. Relative paths zijn altijd relatief aan de **current working directory, een eigenschap van een proces**. 

### Acyclic directed graph directory structure
In deze structuur kunnen meerdere directories verwijzen naar hetzelfde bestand. Een file kan dus meerdere namen hebben. Er kan worden [[Linking to files|gelinkt]] naar files en directories. 
![[acyclic-graph directory visual.png|400]]

### General graph directory structure
In deze structuur kan ook [[Linking to files|gelinkt]] worden naar directories hoger in de hierarchy. 
Er kunnen *cycles* ontstaan als er links naar directories worden ondersteund. Het OS moet ofwel cycles verbieden, of alle file system tools bestand^[haha] maken tegen cycles. 

![[general graph directory visual.png|400]]
