---
aliases: []
tags: [os] 
date: 2022-05-12
---
***
# NVM scheduling 
Traditional HDD schedulers don't make sense for NVMs because of different physical structures. 

Linux uses NOOP scheduler for NVM, implementing FCFS. Requests for consecutive blocks are merged. 

In NVM, read times are uniform but writes are not. Each write might of might not trigger block erasure or garbage collection. 