---
aliases: []
tags: [os] 
date: 2022-02-11
---
Wat doet het OS als een systeem aan wordt gezet?
***
# System boot 
## What happens when a system powers on?
1. CPU starts execution of instructions from **predefined address**
  Usually some firmware, stored in *(EEP)ROM* 
2. Low-level initialization, and boot loader is loaded from specific location on *secondary storage*. 
Sometimes more versatile *second-stage boot loader*; e.g. GRUB. 
3. Boot loader loads kernel from secondary storage to main memory. 
  Then jumps to it. 
4. Kernel does system initialization
5. Kernel loads the initial user-space program
6. System waits for commands