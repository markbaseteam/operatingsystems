---
aliases: [Gelaagde implementatie van bestandssystemen]
tags: [os] 
date: 2022-04-10
---
***
# Layered file system approach
Implementatie van filesystems is gelaagd opgezet. 

## Waarom is het handig het file system op te delen in losse, incrementele delen?
De meeste bestandssystemen werken met dezelfde file/dir structuur, en operating systems ondersteunen meestal meerdere bestandssystemen. Het los implementeren van werken met files en directories voor elk ander bestandssysteem zou dus zonde zijn. 

De bestandssystemen zijn onafhankelijk van het type van opslag, dus de code voor het werken met een apparaat moet los van de code voor het bestandssysteem. Zo kunnen verschillende bestandssysteemimplementaties dezelfde code voor werken met een apparaat gebruiken. 

## Welke losse delen onderscheiden we? 
De opbouw van boven naar beneden is als volgt: 
![[layered file system visual.png|150]]

De belangrijke onderdelen die we behandelen zijn 
- logical file system 
- file organisation module 
- basic file system 
- i/o control 

### Logical file system 
[[Logical file system]]: de generieke implementatie. 
- Abstracte interface voor werken met bestanden via read/write/seek, 
- Routines voor manipuleren van directorystructuren 
- Bijhouden van file protection
- Mogelijk maken van implementeren subclasses van File class, waardoor een [[Virtual File System]] indeling mogelijk is. 

### File organisation module 
[[File organisation module]]: de code voor specifieke bestandssystemen. 
- Mappen van virtuele adressen van bestanden naar fysieke diskblokken, 
- Encoderen directorystructuur, 
- Bestandssysteem bijhouden op vrije blokken. 

### Basic file system
[[Basic file system]]: Abstractie die I/O mogelijk maakt door implementatie van verschillende file organisation modules. 
- Stuurt commando's op bloknivo naar de juiste device driver, 
- Buffering van diskblokken in werkgeheugen. 

### I/O Control 
*I/O control*: De speficieke device drivers, die commando's op bloknivo naar de low-level HW instructies omzetten. 
***