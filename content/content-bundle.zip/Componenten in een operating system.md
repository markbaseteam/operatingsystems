---
aliases: [Components of operating systems]
tags: [os] 
date: 2022-02-11
---
Een korte tour van alle componenten van een operating system. 
***
# Components 
## What are the 6 main OS components?
1. Process Management
2. Memory Management
3. File Management
4. Mass-Storage Management
5. I/O Subsystem
6. Protection & Security

# Process management 
Includes creation/termination, suspension/resumation. 

Control process scheduler properties. 

Providing primitives for communication between processes: *interprocesses communication (IPC)*

# Memory Management  
CPU can only access main memory directly. OS kernel must manage main memory and keep track of which parts belong to what processes. 
Processes may request additional memory. 

Needed space may exceed available physical memory. 

# File Management  
Data is a single long bitstring, the os must organize this in terms of files and directories. It must provide uniform and logical view — regardless of actual physical storage device. 

# Mass-Storage Management  
Control external non-volatile memory devices. These are significantly slower than main memory, so good data structures and algorithms are necessary. 

Disk scheduling, free space and block allocation. 

# I/O Subsystem  
Provide interface for I/O device accesses, device drivers, buffering, caching, spooling^[Temporal storing of output data before being sent to device. This is done for devices without random access.]. 

# Protection & Security
Control access to resources; notion of user IDs. 

# Virtualization
![[Operating System Virtualization]]