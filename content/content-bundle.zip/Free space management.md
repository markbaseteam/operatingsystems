---
aliases: [Bijhouden van beschikbare blokken]
tags: [os] 
date: 2022-04-10
---
***
# Free space management
Bijhouden (on)gebruikte diskblokken met een *free-space list*

## Linked list
Simpel. Wel hartstikke inefficiënt. 

## Contiguous allocation ("counting")
Vaak worden contiguous blocks allocated/released. Waarom dan nog individuele blokken bijhouden? Tuples van (blokadres, $n$) met het adres van het eerste vrije blok van een groep van $n$ contiguous blocks. 

## index blocks ("grouping")
If $n$ blocks are free, the first free block stores the addresses of the following $n$ free blocks. 
The last of these n addresses is address to block that contains the next $n$ addresses of free blocks 
Now the addresses of free blocks are grouped, so addresses of larger number of free blocks is more easily found. 
![[grouping free space management.png|400]]

## Bitmap
Lange bitstring met 1 is gebruikt, 0 is ongebruikt. 
Deze wordt vaak gebruikt. 