---
aliases: [Bestanden afbeelden op diskblokken]
tags: [os] 
date: 2022-04-10
---
***
# Bestanden naar fysieke diskblokken mappen 
Diskblokken zijn vrij klein, vroeger 512 bytes, nu meestal 4096. 
Te grote blokken geeft interne fragmentatie, te kleine blokken betekent dat opslaan van de mapping weer veel ruimte kost. 

## Contiguous allocation
Hierbij is van elke filename een tuple (start,count) om aan te geven welke blokken nodig zijn. 

Niet alle gealloceerde blokken worden voor data uit het bestand gebruikt—we moeten ook metadata opslaan. Om te weten tot waar je de blokken mag uitlezen voor de data, moet je in de [[File Control Block]] kijken. 

### Fragmentatie 
Er kan [[interne fragmentatie]] ontstaan omdat een file gehele blokken toegewezen krijgt, maar de file size niet block-aligned hoeft te zijn 

Ook [[externe fragmentatie]] is mogelijk als er veel kleine gaten zijn tussen de gebruikte blokken. 

### Groeiende blokken
Als files groter worden, kan het zijn dat ze niet meer passen op de originele plek. Dan moeten ze in het geheel worden verplaatst. 

## Linked allocation
Bij *linked allocation* is in de FCB enkel het startblok te vinden. Als we dan volgende blokken willen vinden, moeten we links volgen. 

Op die manier is een groeiend bestand geen probleem. 
Daarnaast wordt ook externe fragmentatie totaal opgelost. 

De pointer kan zich bevinden 
- in een blok zelf (e.g. laatste bytes), of 
- in een *index array* dat zich aan het begin van het bestandssysteem bevindt zijn. 
	- *FAT: File Allocation Table*. 
	- Een voordeel: alle pointers staan op één contiguous plek en kunnen dus **makkelijk worden gecacht**. 

Maar random access (getting to the middle of the file) is kostbaar. 

## Indexed allocation
We wijzen per bestand een indexblok aan, wiens locatie in de FCB te vinden is. Deze bevat in de juiste volgorde links naar alle blokken van de file. 

Dit geeft wel een maximale grootte van een bestand, afhankelijk van hoe groot de blokken zijn en hoeveel ruimte een adres van een blok kost. 

We kunnen wel de blokgrootte verhogen, maar dit is inefficient omdat het maximum slechts lineair groeit. 

## Multi-level allocation 
Analoog aan [[Types of Page table structures|Hierarchical page table]]s. Er is een multi-level index die wijst naar andere indexblokken, etc. 

## Combined scheme 
Dit is vaak gebruikt. Een entry van een bestand in de FCB wordt groter, want het houdt nu bij 
- de filename 
- fcb index 
- blok{1,2} voor kleine bestanden 
- indirect blok voor bestanden die aan 1 indexblok genoeg hebben 
- double indirect blok voor grotere bestanden 

![[Combined scheme file mapping.png|400]]