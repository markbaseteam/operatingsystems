---
aliases: [⏧, ⨳]
tags: [os] 
date: 2022-04-10
---
***
# File organization module 
## Superblock 
![[Superblock]]

## Files en metadata per directory 
Van elke directory moet een file/dir list bekend zijn. 
Dit kan lineair (schaalt niet), of als [[Hash Table]] (ext4), of een [[B-Trees#B+ tree|B+ tree]] (XFS). 

Ook moet metadata bekend zijn. Dit wordt in de [[File Control Block]] opgeslagen. 

### Hoe is de FCB opgeslagen? 
![[File Control Block#Directory vs Inode FCB]]
