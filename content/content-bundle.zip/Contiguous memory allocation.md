---
aliases: []
tags: [os]
date: 2022-03-15
---
***
# Contiguous allocation 
## Wat is contiguous allocation? 
Elk proces zit in een doorlopend stuk geheugen met een vast begin en einde. Geheugenbescherming is nu simpel, want je hoeft alleen te checken of een memory request binnen de limieten valt. We gebruiken het [[Memory management#^cce94A|relocation register]] en een nieuw *limit register*.
**Bij een context switch past het OS de waarde in de relocation en limit registers aan.** 

## Hoe delen we geheugen in bij contiguous allocation?
Elk proces krijgt een segment met het benodigde geheugen. Zodra het sluit, komt dat vrij. 
Maar waar zet je dan nieuwe processen? Dit is het [[Dynamic storage-allocation problem]]. 
Er zijn drie veelgebruikte strategieën: 
- **First fit**: eerste de beste dat groot genoeg is 
- **Best fit**: kleinste gat dat groot genoeg is (moet hele lijst afgaan)
- **Worst fit**: handig om na indelen nog een zo groot mogelijk gat over te houden 

## Welke problemen ontstaan bij contiguous allocation?
Variable partition schemes hebben last van *external fragmentation*: er is genoeg geheugen voor een nieuw request, maar verspreid over meerdere gaten. 

External fragmentation is anders dan *internal fragmentation*. Dit laatste vindt plaats als er meer pages gealloceerd zijn dan nodig voor het eigenlijke geheugen dat in die pages gebruikt is.  ^b91e60

We kunnen deze problemen oplossen door **met compaction de gebruikte segmenten naast elkaar te brengen** zodat er grotere stukken vrij geheugen overblijven. 