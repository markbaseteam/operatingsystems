---
aliases: [Omgaan met corruptie]
tags: [os] 
date: 2022-04-10
---
***
Corruptie kan ontstaan door 
- dram stuk 
- diskfout 
- user error 

Je kan met een *file system checker* het bestandssysteem nalopen. Die gaat alle metadata af en controleert of die consistent is. Daarnaast wordt de hele directoryboom afgelopen. 
Maar dit duurt lang. 

Andere oplossing: [[journaling file systems]] (of log-structured file systems) waarbij een *transactielog* wordt bijgehouden. Dus als een system call de metadata aanpast, dan wordt er een transactie in de log geplaatst. Zodra de transactie op de log staat, zal de system call returnen. Later pas word de transactie echt naar het bestandssysteem weggeschreven. 
Als het systeem onderwijl crasht, kan de volgende mount worden gekeken welke nog niet of half uitgevoerde transacties nog moeten worden gedaan. 
***