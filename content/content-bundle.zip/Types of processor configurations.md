---
aliases: [Processor computer system organisation, Computer system architecture ]
tags: [os] 
date: 2022-02-11
---
Computersystemen kunnen op verschillende manieren worden georganiseerd.
***
# Computer system architecture 
## Single processor (single-core) systems 
Only general purpose CPUs, i.e. no embedded devices. 
Hardly used anymore. 

## Multi-processor systems 
Choice of multiple cores on one chip, multiple CPUs on one system, or both!
There is increased throughput, but as [[Amdahl's law]] states, adding more cores yields decreasing returns. 

Most common CPU structure is *Symmetric MultiProcessing* (SMD), where are CPUs are equal. However, '*big.little*' setups are increasingly common in mobile systems. 

## Clustered system 
Combines multiple computers into a single system, connected with a high-speed network. 
Requires software that is explicitly parallelized. 