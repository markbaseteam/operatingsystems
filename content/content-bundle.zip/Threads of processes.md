---
aliases: OS-level multi-threading
tags: os, ca
date: 2022-01-03
---
***
# Threads and Processes
## What is a thread?
The simplest case is a single process state, program counter and registers belonging tot a process. Then there is only a **single thread of execution**. 

## What is multi-threading?
**Multiple threads means that one single process has multiple threads of execution**, each with their own state, PC, and registers. 

## Why use multi-threading at all?
Easier to program different tasks of a program to happen at the same time (GUI & I/O, word processing, web server)

We can program multiple tasks so that they execute in parallel. 

# Why not use multiple processes instead?
**Thread creation is lightweight in comparison to process creation.** This is because no new [[virtual address space]] needs to be allocated. 

Switching between threads is also faster than between processes, since we know that [[Structure of processes in Operating Systems#What happens when one process is switched to another process|context-switching is pure overhead]]. 

Threads within a single process share the same address space, which makes communication significantly cheaper. 

## How does the OS store process data of a multi-threaded process?
Multi-threaded process has **multiple instruction streams**, which means that the OS needs to save additional stacks, PCs, and registers. 

However, some information is shared: 
- code and data fragments 
- open(ed) files 

Visualized, threads are usually presented as literal pieces of thread. 
![[visualization multi-threading.png|600]]
***

## programming multi-threaded programs

Threads are easier to implement than delicate event loops, with multicore processors it is still hard. 

Main issues: 
- **identifing tasks**: need to find parts of application that can be divided into tasks that can be performed independently. 
- **balance**: threads need to do ~equal amounts of work 
- **data splitting**: distribute the data over CPU cores  
- **data dependency**: tasks need to be synchronised, *if* there are data dependencies
- **testing and debugging**: 
  > “A programmer had a problem. He thought to himself, "I know, I'll solve it with threads!". has Now problems. two he”

## concurrency vs. parallelism
**Parallelism**: system performs more than one task at same time, in parallel. 

**Concurrency**: multiple tasks can make progress, but do not need to run at the same time (can also be done on single processor, with a **task scheduler**)

## types of parrallelism

Two main types: 

**Data parallelism**: larga data set is split and distributed over threads; each thread does same operations on different data 
e.g. image filter

**Task parallelism**: collection of tasks is divided over threads; each thread performs different operations. 
e.g. transaction processing

## implementations of threads 
### history
In past, implemented in **user-space**, with user-space library (because no support back then). 
e.g. LinuxThreads, early Java threads

Later, kernel support was added 
e.g. since Linux 2.6: NPTL thread implementation


### relationship of user- and kernel threads 

#### Many-to-one
A **many-to-one** relationship is when there is a single kernel-level thread, but there are multiple user-level threads. 

This is an older model before kernel support was added. 

There is only one kernel thread, therefore the process can be executed only on one processor. Then when a user-level thread blocks, the kernel-level thread also blocks. 

Advantages: 
- Sometimes user-level thread switching is faster than kernel-level thread switching
- A process can control its own scheduling 

#### one-to-one
One kernel-level thread for every user-level thread

Potential overhead: if many threads are in a process, kernel also needs these

#### many-to-many
$M$ user-level threads to be mapped to $N$ kernel level threads 

-> many user-level threads without introducing too much overhead at kernel level 

#### two-level model 
Small extension of many-to-many (above): also allow user-level threads to be bound specifically to a kernel-level thread



### thread libraries
Functionality always provided by library: these expose an API

Different APIs exist: 
- **Win32**
- POSIX **pthreads** (UNIX systems)
- Java threads

Some more details on pthreads: 
See this [[Screenshot_20210420_151948.png|code example]]

Posix threads are *explicitly* programmed: **explicit threading**

Other libraries/compilers can do this automatically (==still need to specify which tasks can be multi-threaded==): **implicit threading** (see e.g. [[#openMP]] below)

## thread pools 
This contains $N$ threads that wait for work. 
So: no need to create new -> faster 
If all are busy, put new work into queue

This uses the **many-to-many** model 

## fork-join model 
#Todo/Onderzoeken   : add extra info from book, because slide 24 is not very clear

## openMP
Is a standard specifying compiler support for multi-processing, in e.g. C, C++, Fortran

Compiler must support directives, then process code and automatically insert multi-processing code to create and manage threads 

So, ==identifying parallel regions still falls to the programmer!==

Mark like this [[Screenshot_20210420_152729.png|code example]] with ***pragma's***. 
Easy concurrency for `for` loops: [[Screenshot_20210420_152910.png|for loop code example]]

## threading issues 
UNIX was not made with multi-threading in mind (it did not exist then) 

Threads introduced later -> problems with system calls: 
- `fork()` duplicated process, does it also duplicate all threads, or just the one calling?
- `exec()` does it replace all threads? 
  -> this call replaces program image -- shared between all threads  of the process -- and therefore needs to remove all threads and start a single new one 
- **signals**: which thread handles signals?

