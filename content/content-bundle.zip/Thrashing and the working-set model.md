---
aliases: [locality, working set]
tags: [os] 
date: 2022-03-24
---
***
# Thrashing en het working-set model
Als een proces niet genoeg pages gealloceerd heeft gekregen om alles in geheugen te zetten, kan het **continu page faulten**. Dit is bekend als *thrashing*. 

## Hoe kunnen we thrashing voorkomen? 
**Er moeten nooit meer actief gebruikte pages zijn dan er in het fysieke gebeugen passen.** Om dit te garanderen, moeten we bijhouden hoeveel van de pages van een proces actief in gebruik zijn. 

We gebruiken het *locality model*: als een proces uitvoert verandert het vaak van locality. **Een locality is een set van pages dat actief gebruikt wordt**. 

## Working-set model simuleert locality van een proces
Het *working-set model* probeert de localtity van een proces te simuleren. 

De parameter $\Delta$ is de *working set window*. Dan als we naar de laatste $\Delta$ page referentie kijken, krijgen we de *working set* van dat proces. 
![[working set of a process.png|500]]

De $WS(t_{i})$ is de grootte van de working set van een proces. 
Dan is $D = \sum{WS(t_{i})}$ het aantal *demand frames* — het aantal frames dat actief in gebruik is. 
Als $D>m$, dan is demand te hoog en kan thrashing ontstaan. Daarom moeten we processen gaan suspenden of swappen. 
**Reclaimen van pages helpt niet, omdat er te veel nodig zijn om alle processen uit te voeren.**

Er is een verband tussen de working set en de page fault rate. Als een proces een nieuwe locality in gaat kost het even tijd om alle nieuwe pages in de set in te delen. 

## Meten page fault frequency om thrashing te voorkomen 
We kunnen bijhouden wat de page fault rate is van een proces. Als dit te hoog is, dan moeten we extra pages allocaten aan dit proces om thrashing te voorkomen. Als dit laag is, kunnen we pages weghalen van dit proces zonder thrashing te veroorzaken. 