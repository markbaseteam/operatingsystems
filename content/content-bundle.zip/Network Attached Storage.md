---
aliases: [NAS]
tags: [os]
date: 2022-05-12
---
***
# Network Attached Storage
Extra disk over *LAN* (local area network)

Can be done in two ways: 
1.  *File-based*: protocols like NFS, CIFS
	Remote host accessed using requests for files; client does not know about file system of NAS. 
	Multiple clients can access same files at same time


 2. *Block-based*:with *iSCSI*
	Remote host receives requests for blocks, client determines file system. 
	Only one client can access disk at same time (like a regular disk). 
***