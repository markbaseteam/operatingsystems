---
aliases: [processor performance equation, cache performance]
tags: [ca,os] 
date: 2021-10-15
---
# Processor performance equation 
Wordt gebruikt om over de [[Measuring & Reporting Performance|performance van systemen]] te rederen. 
Ook [[Caching#Cache performance|CPU Caching]] gebruikt een [[#Cache performance|uitgebreidere versie]] van de equation om uit te drukken welke snelheidswinst behaald is.
***
Elke computer aangedreven door een klok: we hebben de **CPU time** $$\text{CPU time} = \frac{\text{CPU clock cycles for program}}{\text{Clock rate}}$$

De inverse hiervan is de **Clock Cycles per Instruction** $$\text{CPI} = \frac{\text{CPU clock cycles for program}}{\text{Instruction count}}$$
CPI zegt iets over de efficientie van de microarchitectuur: in het algemeen is een hogere CPI beter per klokfrequentie.  ^4a474b

*** 

Tezamen hebben we de **CPU time equation**: $$\frac{\text{Instructions}}{\text{Program}} \times \frac{\text{Clock Cycles}}{\text{Instruction}} \times \frac{\text{Seconds}}{\text{Clock cycle}} = \frac{\text{Seconds}}{\text{Program}} = \text{CPU time}$$

Veranderen van elementen van een deel van de vergelijking heeft weer invloed op andere breuken. 
E.g. instructies in een programma verminderen door van RISC naar CISC te gaan -> hogere CPI door complexe CISC instructies. 

***

Voor elke (groep van) instructie(s) *i* weten we de CPI en dus kunnen we de **CPU clock cycles** berekenen: $$\text{CPU clock cycles} = \sum_{i =1}^{n}{IC_i \times CPI_i}$$

De totale CPI volgt dan uit de formule voor **totale CPI**: $$\text{CPI} = \sum_{i =1}^{n}{\frac{IC_i}{\text{Instruction count}} \times CPI_i}$$

# Cache performance
Memory stall cycle is een clock cycle waarin de processor aan het wachten is op geheugen access. 
We hebben de **CPU execution time** equation: $$\text{CPU execution time} = \left(\text{Clock cycles} + \text{Stall cycles}\right) \times \text{clock cycle time}$$

Het aantal memory stall cycles hangt af van het aantal cache misses en de kosten van een miss (de **miss penalty**). 
We hebben de **stall cycle** equation: $$ \begin{align*}
\text{Stall cycles} &=\text{\# misses} \times \text{miss penalty}\\
&= \text{IC} \times \left(\frac{\text{misses}}{\text{instruction}}\right) \times \text{miss penalty}\\
&= \text{IC} \times \left(\frac{\text{memory accesses}}{\text{instruction}}\right) \times \text{miss rate} \times \text{miss penalty}\\
\end{align*}$$ 

# Pipeline performance 
De pipeline CPI is gegeven door 

$$\text{CPI} = \text{Ideal CPI} + \text{Structural stalls} + \text{Data hazard stalls} + \text{Control stalls}$$ ^767d30

# Speedup 
De performance increase die kan worden behaald door paralleliseren is beperkt. 
Zie [[Amdahl's law]]: 
$$
\text{speedup} = \frac{1}{(1-\text{Frac}_\text{enh})+\frac{\text{Frac}_\text{enh}}{\text{Speedup}_\text{enh}}}
$$
