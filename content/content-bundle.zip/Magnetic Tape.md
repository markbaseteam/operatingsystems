---
aliases: [tape]
tags: [os]
date: 2022-05-12
---
***
# Magnetic tape
Secondary storage medium of choice, before [[Hard Disk Drives|hdd]]s became in use. 
It uses a magnetic tape spool to store data. 

Modern LTO-6 cartridge can store 2.5 TiB data, and there is still work on increasing the density. 

Nowadays, it is mainly used for archiving and backups. 

Random access is *very slow*, because the tape needs to be winded. After that r/w speeds are relatively fast, ~150 MiB/sec—similar to HDDs.
***