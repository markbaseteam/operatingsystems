---
aliases: []
tags: [os] 
date: 2021-03-08
---
***
# Translation Look-aside buffer
## Wat zijn de gevolgen van paging voor prestaties van virtueel geheugen?
Elke acces heeft **minimaal een keer vaker een memory access** nodig, omdat we moeten vertalen. 

## Hoe wordt een adres vertaald met een TLB?
Dit kan met een *cache* worden versneld: de Translation Look-aside Buffer. Vaak [[Comparing cache architectures#^a73afc|Fully Associative]]. 

We zien dat bij het vertalen van het page nummer, als eerste wordt geprobeerd om in de TLB te zoeken. Als dat niet lukt (een miss), dan moet in de page table worden gekeken. 
![[page table using TLB.png|400]]

Een concreet voorbeeld is hier te vinden: [[Virtual memory address translation]]. 


## Wat doen we als de TLB vol is?
Als de TLB vol is, moeten kiezen welke entry eruit wordt gegooid, door een [[Page Replacement|Page replacement algorithm]]. 

## Zijn alle logische adressen uniek? 
Verschillende processen kunnen dezelfde logische adressen aanspreken, die fysiek wel anders zijn. Maar in de TLB gebruik je het logische adres als locatie, dus is er **overlap in adreswaarden bij meerdere processen tegelijk in de TLB**.  
Dus we kunnen de TLB flushen elke keer als er een context switch is, of anders een *address space identifier* (ASID) opslaan naast het virtuele adres (e.g. simpelweg het proces PID). 

## Hoe drukken we de prestaties van de TLB uit? 
Net als CPU caches is een hoge hitrate belangrijk. 
We kunnen het *effective memory-access time* (EAT) berekenen gebaseerd op de hitrate $h$, en memory access time $m$:
$$\text{EAT} = [h \cdot m] + p(1-h) \cdot 2m]$$
Dan zien we dat het **verhogen van de hitrate** van 80% ($0.8\cdot 10 + 0.2 \cdot 2 =12$) naar 99% ($0.99\cdot 10 + 0.01 \cdot 20 =10.1$) **diminishing returns geeft**. 

Iets netter uitgedrukt: 
$$\begin{align*}
\text{EAT} &= (\text{cache lookup}) + (\text{page table lookup})\\
\text{cache lookup} &= (\text{hit rate}) * (\text{mem access time}) \\

\text{page table lookup} &= (\text{1 - hit rate}) * (\text{mem access time} * 2)
\end{align*}$$


## Hoe kan paging memory protection verbeteren? 
We kunnen elke page als extra attribuut individuele permissions hebben, e.g. r/w/e, en soms zelfs per-page caching. 

## Hoe houden we bij welke pages in gebruik zijn? 
We voegen nog een attribuut toe, de *(in)valid bit*. Als die invalid is komt er een OS trap. 

Nu kunnen we ook processen **gedeeltelijk laden**: niet geladen pages hebben een invalid bit, en als ze worden aangesproken dan komt er een trap naar het OS die de page laadt.  ^db441a

We kunnen ook pages delen tussen processen, e.g. voor [[Interprocess communication]], of shared libraries. 