---
aliases: [Storage devices]
tags: [os] 
date: 2021-05-31
---
***
# Mass storage
## Local mass storage 
Two systems common: 
- [[Hard Disk Drives]] (HDD): workstations, server systems
- [[Non-Volatile Storage]] (NVM): SSD drives, NVMe, USB sticks, SD cards

And in the past [[Magnetic Tape]] 

## Networked mass storage 
Also ***networked disks***. Three main methods: 
- [[Network Attached Storage]]: **NAS**
  A disk made accessible over regular LAN
- [[Storage Area Network]]: **SAN**
  Special netword dedicated to storage
- [[Cloud Storage]]
  Provides some form of API to access data; often in form of **objects**
  
## RAID
 Disks can be organised through [[RAID]] ("Redundant array of inexpensive / independent disks")