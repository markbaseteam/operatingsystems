---
aliases: []
tags: [os] 
date: 2021-10-21
---
***
# Computing environments 
Brief overview of many different computing environments. 

## What are the 6 main computing environments? 

- Traditional computing
- Mobile computing
- Client-server computing
- Distributed computing
- Cloud computing
- Real-time operating systems


# Traditional computing 
- Originally: *mainframes* with terminals. 
- '90s: file/print servers with **stand-alone PCs** connected as **clients** through office network 
- Now: Networking and internet everywhere; interactive web services

# Mobile computing
Mobile computing has access to special features like GPS, touch screen, sensors, etc. Limited memory capacity. 

Processing power usually *not an issue*, but performance per power consumption is! 


# Client-server computing 
*Client* connects to *server*, and requests service, e.g. 
- compute server (*compute-server system*)
- file server (*file-server system*) solely to access and modify files

Servers respond to client requests. 

Originates back to office networks, but stil in use: most websites!

# Distributed computing 
Collection of machines connected by network. **Can be different machines**!

Past: Network Operating Systems **combining collection of computers into single entity**. 

Now also: *peer-to-peer networking*; dynamic systems in which all nodes are equal; there is no single "controlling" entity.

# Cloud computing 
*Infrastructure as a service (IaaS)*: temporarily rent computing and storage services from vendors. 

Based on [[Operating System Virtualization]] techniques. 

# Real-time operating systems 
Special purpose, often limited. Often for embedded devices. Usually triggers actions in response to sensor data. 

Cars, airbag controllers, CD players, etc.

See also [[Real-Time Scheduling]]