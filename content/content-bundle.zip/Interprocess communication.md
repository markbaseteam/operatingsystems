---
aliases: [IPC]
tags: [os] 
date: 2022-02-28
---
***
# Interprocess communication
```toc
max_depth: 1
```

## How are processes categorized based on their relation to other processes?

Processes are either 
- **independent**: cannot affect/be affected by others 
- **cooperating**: opposite of ↑. Consequence: *"any process that shares data is cooperating"*

## Why is there a need for IPC?
Cooperating processes need to communicate for 
- information sharing 
- computational speedup (dividing workloads)
- modularity (e.g. through [[Pipelining]])

# Which two types of IPC are used most often?
Two models: 
- **shared memory** 
- **message passing**

![[shared memory vs message passing.png|500]]


# Shared memory IPC
## How does shared memory IPC work?
A single block of memory is accessible by multiple processes. Sharing is then done through the processes, and **the kernel is not involved**. A consequence is that the kernel can not step in to resolve request conflicts. 

The kernel does however offer mechanisms for synchronisation. This is described in Chapter 5, which is discussed in Lecture 14: [[schets synchronization tools]]. 

# Message passing
## What is message passing?
The idea is that the OS offers system calls to send and receive messages between processes. The actual communication is done by the OS kernel. 

Message passing is not just used for communication, but also for [[process synchronization]]. 

## In which two categories is message passing IPC divided?
There is **direct** and **indirect** communication. 

## What is direct communication? 
In direct communication, the sender must explicitly provide a receiver, and vice versa. Calls that are matching are automatically connected by the OS. 

A link is therefore between exactly one pair, not more. 

Links can be **both unidirectional and bidirectional**. 

## What is indirect communication?
In indirect communication, messages are sent to a **mailbox**. 
The sender and receiver do not need to name each other. 

The mailbox has an ID, and only processes with a valid ID can access messages in that mailbox. 

Therefore, more than two processes can communicate. 
Additionally, a single pair of processes can use multiple mailboxes to communicate. 

## What happens on communication conflicts?
If K sends a message to A, and L/M both try to receive the message, who receives it?

The implementere must choose! There are many ways to approach this: 
- allow at most 2 processes per mailbox (but then the advantage over direct communication is gone!)
- allow at most one process to perform `recv()` on one mailbox at the same time
- the OS chooses an arbitrary process

# Message synchronization
## Wat is het verschil tussen synchronous en asynchronous communication?
Met synchronous communication, blokkeert het proces dat verstuurt. Daarom heet het ook wel **blocking communication**. 

Met asynchronous communication gaat het proces dat verstuurt verder zonder te blokkeren, en het ontvangende proces probeert te ontvangen (vaak i.c.m. een timeout). 

## Wat is een synchronization primitive?
Met blocking communication kan je een synchronization primivite bouwen: **[[rendezvous messaging]]**. Het proces kan enkel verdergaan met uitvoeren als het andere gepaarde proces ook dat punt heeft bereikt. 

# Buffering 
## Waarom moet er worden gebufferd?
Als er non-blocking communication (dus asynchronous communication) plaatsvindt, moet de OS de berichten **bufferen omdat ze niet gegarandeerd zijn gelijk te worden ontvangen**. 

## Hoe is het bufferen geïmplementeerd?
De implementatie gaat via een **bounded buffer, unbounded buffer of zero capacity buffer**. 

De unbounded buffer kan blijven groeien, met als enige limiet het systeemgeheugen. 

De bounded buffer is van een vaste grootte. Als een proces naar een volle buffer iets probeert te sturen, dan vindt er ofwel een **blocking send, of een send failure** plaats. 

Bij een zero capacity buffer moeten de verzonden en ontvangende calls bij elkaar passen. Dit maakt [[rendezvous messaging]] mogelijk. 

# Pipes 
## Normale pipes
Voor locale IPC (binnen een proces) worden vaak **pipes** gebruikt. 
Deze werken als *producer-consumer*: er is een **unidirectional link**. 

Normale pipes bestaan alleen binnen het proces dat ze heeft gemaakt, dus als je een pipe wil gebruiken voor IPC, moet je [[Processen#Fork Exec|forken]]. 

## Named pipes
Er bestaan ook **named pipes**, die toegankelijk zijn via een bestand dat in het bestandsysteem is gemaakt. Op die manier kunnen meer dan twee processen gebruik maken van de pipe. 

In dit geval is de communicatie **bidirectional**. 