---
aliases: []
tags: [os] 
date: 2022-04-19
---
***
In UNIX staan alle open bestandssystemen in een boom. **Mounten is het ophangen van een bestandssysteem in de boom.** 

Als er meerdere volumes zijn, moeten die benaderbaar zijn vanuit een *hoofdboom*, de *root partition*. Deze root partition heeft meerdere plekken waar andere bestandssystemen aan kunnen worden opgehangen, de zogeheten *mount points*. 
***