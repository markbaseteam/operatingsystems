---
aliases: []
tags: [os]
date: 2022-04-10
---
***
De basic file system is een generieke module die door alle implementaties van bestandssystemen kan worden gebruikt. Het vormt de laag tussen de specifieke implementaties en de low-level device drivers. 

Optimalisaties zijn 
- *Asynchronous writes*: tell application that does `write()` syscall that the operation has finished, but buffer the data to be written and write to disk later. **Some application require synchronous writes, because they are safer** (data is guaranteed to be written once syscall returns) 
- *Read-ahead*: If the OS kernel detects sequential reading, it can read next blocks before it is acutally requested (and also blocks that have been read can be purged from buffer cache, *free-behind*)
***