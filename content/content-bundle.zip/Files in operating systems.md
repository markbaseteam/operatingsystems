---
aliases: [bestanden]
tags: [os] 
date: 2022-04-04
---
***
# Files 
## Wat is een file? 
Een file is een [[Abstract Data Type]] met bijbehorende operaties: 
- read data from a pointer location 
- write data from a pointer location
- create a file, remove a file 
- truncate a file after a pointer 

## Hoe kunnen we operaties uitvoeren op een file? 
Om operaties uit te voeren op een file, moet deze geopend zijn. Dit is een operatie niet op de file, maar op de *directory structure*. Hierbij wordt binnen de directory gezocht naar de file met de gegeven filename; als dit lukt kopieert de kernel de inhoud van de data en attributes naar de in-memory structure van het OS. 
Als de operaties klaar zijn, moet de file weer worden gesloten, waarbij alle veranderingen aan data en attributes weer naar disk worden geschreven. 

## Hoe voorkomen we dat meerdere operaties door elkaar worden uitgevoerd? 
Het OS implementeert [[File locking]]. 

## Hoe komen we achter de interne structuur van een file? 
De inhoudelijke organisatie van files is zelf in te delen door de gebruiker (behalve files die de OS moet lezen, zoals [[ELF file format]]). 

File extensies kunnen aangeven wat de inhoudelijke structuur van een bestand is, maar dit is niet altijd nodig. Sommige systemen slaan file type in de attributen op, en sommige systemen gebruiken *file sniffing* om op dynamische wijze het file type te ontdekken. 
