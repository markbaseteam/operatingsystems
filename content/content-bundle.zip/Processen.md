---
aliases: [Processen en programma's, Processes]
tags: [os] 
date: 2022-02-11
---
***
# Processes and Programs
## What is a program? 
A *passive* entity stored on secondary storage with instructions and initialization data. 

## What happens when a program is loaded into memory?
A stack and heap are allocated. The program will maintaine the state in the CPU registers, most notably the *program counter*. 

Once it is loaded, it is active, and we refer to it as a *proces*. 

# Process structure 
## What parts does a process consist of?
- *Text section*: program code = instructions 
- *Data section*: initialization data for global variables 
- *Stack*: temporary data, used during execution to create local vars, pass function arguments etc. 
- *Heap*: contains dynamic memory allocation (explicit allocation using `new` and `alloc`) 

## How are process parts organized in memory?
In the memory that is allocated, the stack is placed on top. It grows downwards. From the bottom, first the text is placed, then the data. Both are a fixed size. On top of those two, the heap is placed and grown upwards. 

# Process state 
## Which 5 states can a process be in? 
Each process must be in one of these states: 
- *New*: process is being created. Needs to be admitted. 
- *Ready*: process ready to be run (waiting to be [[Cpu Scheduling|scheduled by cpu]])
- *Waiting*: process can't continue until I/O operation is done or event wait is done
- *Running*: executing functions. Can transition to ready with an interrupt, or waiting because of I/O or event wait. 
- *Terminated*: process being terminated 

![[process state transition.png|500]]

# Process creation 
## How are processes created?
The first parent is created by the kernel. All other processes are *children* of another process. This leads to a process tree. See also [[System Boot]]

On creation, processes are assigned a process identifier, the *pid*. 

## What considerations must be made when creating a process? 
- Which resources to share between parent & child? All, some subset, none? 
- Should parent wait (block) until child has finished, or use concurrency? 
- What about open files and network connections? 
- What if the parent terminates when the child is still active? 

# Fork & Exec
## In UNIX, how can a process create a child process? 
Create processes with 
- `fork()`, where a new process is made as a copy of the parent's address space. It is an exact copy, except the PID. 
This function returns $<0$ when the operation failed to the parent, and otherwise returns $0$ to the child process, and the PID of the child $>0$ to the parent process.  
- `execv()` replaces the executable image into address space, 
	- replaces text, data, stack, heap 
	- the file descriptor *state* is not modified!

# Process termination 
## How are processes terminated? 
Termination happens either voluntary of involuntary: 
- **voluntary**: process uses `exit()` call. 
- **involuntary**: parent uses `kill()`; requests OS to terminate the child. 

## What happens on an exit call?
The kernel deallocates all resources, except the process table slot and the  status code. 

If parent was waiting, the exit code of the child is communicated to the parent. Otherwise the child becomes a *zombie process* until the parent cleans it up. 

The process table slot is only released once the parent calls `wait()`.

## Why would a kill call be made?
Done because of 
- No longer needed (quit by user) 
- Task behaves incorrectly 
- Exhausted resources 
- Parent is exiting, and system enforces *cascading termination* — child processes without parent (*orphans*) are not allowed to continue executing. 