---
aliases: [swapping]
tags: [os] 
date: 2021-03-08
---
***
# Swapping 
## Wat gebeurt er als het geheugengebruik te groot is voor main memory? 
We kunnen *swappen* naar secondary storage, zodat in totaal meer dan het main geheugen kan worden aangesproken. 

Gebeurt niet vaak in mobiele devices, want secondary storage is vaak nog klein en flash memory heeft een beperkte lifetime. 

