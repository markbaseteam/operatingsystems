---
aliases: [NVM]
tags: [os] 
date: 2022-05-12
---
***
# Nonvolatile memory devices
These are not mechanical like the [[Hard Disk Drives|hdd]]. 

## What is the physical structure of NVM storage? 
Memory consists of electric cells; flash memory in separate channels. These channels are interleaved so that parallel access is possible; one busy chip does not cause stalls for access to the other chips. 

The microcontroller manages the flash memories, and the communication with the host (the device connected to the NVM device). 

## What are the (dis)advantages of NVM?
Unlike HDD, no moving parts! 
- Less chance of mechanical failure 
- **No seek time or rotational latency** 
- Less power usage

But there are problems with the *memory cells*: 
- They wear out after use much faster than HDD disks
- The controller logic can have bugs (because it is programmed by humans). It is far more complex than moving a disk head to the required disk sector as in HDDs. 
- Blocks need to be formatted before they can be written to, meaning that editing a single page results in a format and rewrite of the entire block. 

## What is the logical structure of the data? 
Like a HDD, the NVM can be written to in *page* increments. These are grouped into *blocks*. 

An important disadvantage of the nonvolatile memory cells is that **pages cannot be overwritten**. In order to edit a page, it needs to be formatted first. But **formatting can only happen at the block level**. 


## How fast are read/write/format operations relatively? 
Reads are fast, writes slower. But block erasure is much slower than either. 

What do we do then? **Let the controller write to another (free) block before the current is finished formatting!**

## What functions does the controller need to manage?  
The controller can choose a different block to write to, and mark old one as invalid. 
If one block is rewritten multiple times, different pages contain older versions of this block. We need the most recent one when reading. 

But, the OS doesn't know this, and still uses allocated contiguous addresses. 

Therefore the controller implements a **mapping from logical blocks the OS uses, to the physical pages that are in the flash memory**. This is known as the *flash translation layer* (FTL). 

### How do we know which pages contain valid data in the FTL mapping? 
In order to manage this mapping, the controller is responsible for 
- *Garbage collection*: the controller clears invalid (old) blocks in order to free up space for new data. 
- *Wear leveling*: since flash chips have limited number of rewrite cycles before they fail, the controller distributes the rewrite load uniformly. 
- *Bad block management*: once chips start failing, the controller maintains a list of them in order to prevent data loss. Some blocks are faulty just after fabrication, so the controller initializes this list at factory testing. 

# TRIM
If we overwrite a page, we need to read all pages of the block it is in, erase the block, and then write back. Potentially many more write operations for a single page rewrite; *write amplification*. 

On OS level, if a file is deleted only the file system data structures are updated. Only once a new file is allocated at the location are the blocks overwritten. 

But on NVM device, one page might be deleted while the rest of the pages in the block are not. If we overwrite that block, the rest of the pages are also deleted. 

In order to solve this, the *TRIM* command can be used. OS support is necessary. The OS tells the NVM what blocks are deleted, and the controller can decide when/if to not preserve the data in future overwrites of neighbouring pages in the same block. 

## Scheduling 
See [[NVM Scheduling]]. 