---
aliases: []
tags: [os] 
date: 2022-02-11
---
Systems calls worden gebruikt door user-mode programma's om gebruik te maken van services die door het OS worden aangeboden. 
***
# System calls 
## What is a system call?
The system call interface forms the main programming  
interface to the services provided by the Operating System  
kernel.  It is the barrier between user- and kernel-space.

## How are system calls performed?
System calls are invoked in traps. The mechanism differs per platform, which means that it is wrapped in C/C++ libraries, with the actual implementation provided by that platform's version of the libraries. 

The function signatures of the system calls are known as the *OS API*. 

## Which parts of a system call implementation need to be documented in the API?
The interface needs to contain 
- the trap mechanism to trigger the mode switch 
- how to communicate which system call needs to be performed 
- how arguments are passed to the system call, e.g. through registers, the stack, or a pointer
- how the return value is communicated back to the process 

## What are system calls used for?
Some examples of system calls: 
- Process management
- Memory management 
	- heap/stack manipulation within process 
	- allocate memory 
	- map files to memory areas 
- File management 
	- open, close, r/w files 
	- directory manipulations 
- Device management 
- System information 
	- date/time/uptime 
	- kernel log buffer (`dmesg`)
- Communication 
	- local processes: [[piping in c#piping processes in C|piping]]
	- network communication 
