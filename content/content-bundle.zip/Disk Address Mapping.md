---
aliases: []
tags: [os]
date: 2022-05-12
---
***
# Address mapping
Hard drives are large 1d arrays of logical blocks. This is different to the actual physical layouts of the disks (with multiple platters) and NVMs (with the [[Non-Volatile Storage#What functions does the controller need to manage|flash translation layer]]). 

## Hard disks 
For hard disks, sectors are numbered sequentially from the first sector of the first track of the outermost cylinder. Most HDDs have some extra blocks that are used in case of bad blocks (this happens through firmware, thus not visible to OS). 

## NVM
See [[Non-Volatile Storage#What is the logical structure of the data|Logical structure of NVMs]]. 
***