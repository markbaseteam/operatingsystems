---
aliases: [Translating a virtual address with hierarchical page tables]
tags: [os] 
date: 2022-03-15
---
***
# Virtual memory address translation 
Some important contepts: 
MMU translates virtual memory to physical memory
 ![[Screenshot_20210329_162956.png|600]]
 
 It does this using a [[Types of Page table structures|page table]]: the virtual address has a *page number* and *offset*. Together these point to the physical file/location. 
![[Screenshot_20210329_163011.png|600]]
These page tables can become far too large really quick. On older systems, 32-bit addresses are used: 
> [!example]+ Example: 

Gegeven: 
- 32-bit address, 
- 4KiB page size ($2^{12}$ bits, dus 12 bit offset), 
- page number van 20 bits (over na 12 offset bits)
- page table entry van 32 bits (4 bytes) (gegeven dat addressen 32 bit zijn)

Dan krijg je per proces al $2^{20}\times 4 = 4\text{ MiB}$ 


![[Screenshot_20210329_163031.png|600]]
And a 64-bit system uses 48-bit addresses: 
![[Screenshot_20210329_163950.png|600]]

Solution? Smarter data structure!
![[Screenshot_20210329_164157.png|500]]
Often, multiple layers/depths are used: 
![[Screenshot_20210329_164222.png|600]]

Maar dus als het fout gaat moet je '1 halen, 5 betalen'. 
How to solve? **Caching**!
![[Screenshot_20210329_164446.png|600]]

Maar het moet parallel gaan voor snelheid, dus TLB grootte is beperkt. Daarom vaak L1 en L2 caches. Miss? -> page table walk

Andere oplossing: grotere page sizes, dus minder wandelen en minder adresvertalingen. Maar, interne fragmentatie neemt toe