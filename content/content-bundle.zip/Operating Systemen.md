---
aliases: Operating Systems, OS
tags: toc, os
---
***
![[os_banner.jpg]]
***
```toc
max_depth: 1
```

Voor opdracht 1: 
- [[directory entry file types in c]]
- [[working with files in C]]
- [[execv no such file in directory fix]]
- [[using execve in C]] 
- [[some C-specific fixes]]

# 1. Operating Systems
Een [[Introduction to Operating Systems]]. 

# 2. Operating system structure
We kijken naar Structuur van Operating Systems. Hieronder valt de [[Types of processor configurations|processorconfiguratie]]. OS worden gebruikt in verschillende [[Computing Environments]]. 

Moderne systemen zijn [[Multiprogramming Systems]], waarbij meerdere gebruikers en programma's door elkaar kunnen worden gebruikt. 
Het OS gebruikt [[Dual structure in operating systems|dual-mode operation]] om kritieke processen van gebruikersprogramma's te scheiden. 

# 3. Computing environments & OS structrures 
We kijken naar welke [[Componenten in een operating system|componenten]] verantwoordelijk zijn voor OS taken. Deze componenten zijn services die het OS ondersteunt. De gebruikersomgevingen (GUI and CLI) zijn verbonden met de [[System Call]] interface om gebruik te maken van deze services. 

Er zijn verschillende manieren waarop de kernels [[Kernels]] kunnen worden opgebouwd. 

We kijken naar wat er gebeurt tijdens de [[System Boot]]. 

Dan gaan we even naar hoofdstuk 3, over [[Structure of processes in Operating Systems]]. 

Programma's zijn inactief op een externe locatie, en worden eaen actief [[Processen|proces]] wanneer het programma start. Processen kunnen kinderen maken, door zichzelf te kopieëren of een `execv` system call te doen. 

# 4. Process Implementation
We hebben het over hoe processen kunnen communiceren via [[Interprocess communication]]. Dit wordt ook gebruikt voor [[process synchronization]]. 

Ook heel kort over [[Process Scheduling]]. 

# 5. Memory management 
Geheugen is cruciaal voor het werken van een computer. 
Bijna alle geheugen is tegenwoordig byte-addressed. Er zijn dus veel bytes beschikbaar. Er zijn veel processen in het geheugen, die het gezamenlijke onderlinge fysieke geheugen delen. 

Het OS beslist welke data van het proces waar in het geheugen wordt plaatst. Zie [[Memory management]]. 

Als we meerdere processen tegelijk willen laden, moeten we die allemaal apart geheugen geven en zorgen dat ze niet andermans geheugen aanpassen opf lezen. 

Memory allocation techniques zijn onder andere  
- [[Contiguous memory allocation]]: in één doorlopend stuk in het geheugen 
- [[Segmentation memory allocation]]: een soort van paging maar in plaats van het geheugen in delen op te splitsen, worden programma onderdelen gesplitst
- [[Virtual Memory]] maakt [[Paging]] mogelijk

# 6. Paging & virtual memory techniques 
We breiden paging uit met advanced paging techniques:
 - De [[Translation Look-aside Buffer]] werkt als cache om [[Virtual memory address translation|vertalen]] van virtueel naar fysiek sneller te maken 
 - Bij het kiezen van een [[Types of Page table structures]] moeten we balanceren tussen performance en nodige opslagruimte 
 - Met [[Memory swapping]] worden pages naar secundaire storage verplaatst om in het main geheugen plek te maken. 

Daarnaast kijken we naar hoe Virtual Memory werkt door middel van [[Virtual Memory#Demand paging|demand paging]]. 

Er is ook een voorbeeld van hoe we een adres vertalen van logisch naar fysiek: [[Virtual memory address translation]]. 

# 7. Memory management 
We kijken naar de [[Virtual Memory#Wat zijn de kosten van demand paging|performance impact]] van demand paging. 

Pages die read-only zijn kunnen makkelijk worden gedeeld. Maar we moeten [[Copy-on-write]] gebruiken als we ook pages met write permissions willen delen. 

Als we een nieuwe page willen neerzetten kiest het [[Page Replacement]] algorithms een page om te vervangen als het geheugen vol is.  

[[Page Allocation]] gaat over het verdelen van pages tussen processen.  [[Page Allocation#Page locality|locality]]  geeft aan uit welke set van pages een proces kan kiezen. 

Als een proces niet genoeg pages gealloceerd heeft, kan er [[Thrashing and the working-set model|thrashing]] ontstaan. 
Het [[Thrashing and the working-set model#Working-set model simuleert locality van een proces|working-set model]] probeert dit te voorkomen door het mogelijk te maken te simuleren hoeveel actieve pages een proces heeft. 

# 8. File system interfaces 

[[File system organisation]] is nodig om de single byte string van een disk toegankelijk te maken. 
Belangrijke concepten zijn [[Files in operating systems]] en [[Directories in operating systems]]. 

[[Linking to files]] can be done in different ways, using a [[File Control Block]] or [[Inodes in UNIX|Inodes]]. 

# 9. Implementations of file systems 
Slides week 9: [[schets File system implementation]]

Besturingssystemen ondersteunen verschillende bestandssystemen. Omdat we niet alle code willen hergebruiken, is er de [[Layered file system approach]]. Die bestaat uit onder andere de [[File organisation module]] en het [[Basic file system]]. 

Als we de (stuk van de) bytestring van een disk willen indelen volgens een bepaald bestandssysteem, moeten we die eerst formatteren: [[Considerations of designing file systems]] 

We kijken naar hoe het mappen van bestanden naar fysieke diskblokken gaat: [[Mapping files to fysical disk blocks]]

De [[File organisation module]] houdt de metadata per bestand bij. 

Ook [[Handling file system curruption]] is belangrijk. 




# 10. mass storage structures
Secondary storage devices are [[Mass Storage Structures]].

Two common secondary storage systems are [[Hard Disk Drives]] and [[Non-Volatile Storage]] devices. On the network, [[Network Attached Storage]] or [[Storage Area Network]] can be used. 

The physical structure of storage devices needs to be mapped to the logical blocks, see [[Disk Address Mapping]]. 

The OS needs to use available secondary storage in an efficient and effective manner. See [[Hard Disk Scheduling]] and [[NVM Scheduling]].

A logical mapping of multiple disks can be implemented with [[RAID]], in order to create redundancy or increase speed. 


# 11. multithreading 
 also [[Threads of processes]]

In the past, processes were a single instruction stream: 
- 1 set of registers, 
- 1 program counter 
- 1 stack

On a blocking system call, this would cause the whole process to freeze. Nowadays, many applications are [[Threads of processes|multi-threaded]]. 

Programs have to be [[Programming multi-threaded programs|written]] specifically to exploit multi-threading. 

# 12. CPU scheduling 
slides week 13 [[schets cpu scheduling]]

# 13. synchronization 
**Lecture**: slides week 14 [[schets synchronization tools]]

**Oefenmateriaal**:
- race conditions in [deadlock empire](https://deadlockempire.github.io/)
- korte practische oefening op lokaal linux systeem, op BS.  

# Tentamens 
[[tentamen OS 20190612]]