---
aliases: [Demand paging]
tags: [os] 
date: 2022-03-16
---
***
# Virtual memory 
Handig: 
- processen deels in geheugen laden 
- swap file gebruiken om processen te laden die meer geheugen nodig hebben dan main memory 
- page sharing voor IPC, shared libraries 

# Demand paging 
## Is het nodig een heel programma bij uitvoeren in geheugen te laden? 
Als we een `execv` doen zorgt het OS dat alleen de nodige pages gelijk daadwerkelijk in het geheugen worden gezet. De rest wordt **on demand geladen**. Het OS doet dit zonder dat de programmeur hiermee rekening hoeft te houden. 
ADVANCED PAGING TECHNIQUES#^
We zagen eerder al dat [[#Wat is de routine voor een page fault|een invalid page een OS trap geeft]] zodat de page kan worden geladen. Dit noemen we een *page fault*. 

## Wat doet het OS als er een page fault is? 
1.Beslis of het adres überhaupt valide is (in de address space van het proces). 
Anders SEGSEGV. 
2. Breng page in geheugen, door vrije page te zoeken. 
3. Vindt bijbehorende frame en laadt de page erin. 
4. Update page table entry 
5. Restart instructie die fault veroorzaakte (herinner je [[Processor Exceptions#Restartable pipelines|restartable pipelines]] nog?).

Zie deze diagram: 
![[page fault handling.png|500]]


## Moet een proces pages laden bij uitvoeren? 
We kunnen kiezen om **een proces te starten zonder pages in geheugen**, dan krijgen we *pure demand paging* .


## Wat is de routine voor een page fault?
1. CPU initiates page fault trap and jumps to kernel routine. 
2. OS saves register & process state
3. Check if virtual adress is valid (within address space of process)
4. Translate virtual to physical 
5. Allocate free frame 
6. Request page to be read from secondary storage
	1. request waits in queue for device
	2. request is serviced, depends on seek time 
	3. disk contrller triggers interrupt when completed
7. OS interrupt handler starts 
8. Save registers & process state of other processes being executed 
9. Modify page table entry 
10. Put page faulting process in ready-list

## Wat zijn de kosten van demand paging? 
Het is duur. Performance is gegeven door de volgende formule. Het boek heeft een alternatieve [[Effective Access Time]] formule: 
$$\displaystyle \text{EAT} = [(1  - p)  \times m] + [p \times \text{(fault page time)}]$$ 
De meest dure stappen zijn 
- handelen van page fault interrupts (~1000 instructions 100 microseconds)
- reading from disk (5 milliseconds)
- resuming a process ( 100 microseconds)

Secondary storage access domineert de kosten. 

Given access time of 200 ns, then **even 1 out of 1000 faulting accesses increases costs by a large amount**: compare perfect paging time of 200 ns versus $0.999 \times 200 + 0.001 \times 5000000 = 5200\mu s$ .

