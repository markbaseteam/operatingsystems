---
aliases: [Kernels in operating systems]
tags: [os] 
date: 2022-02-11
---
***
# Types of kernel 
## Which types of kernels are used?
There are two main types of kernels: 
1. monolithic kernel
2. micro kernel 

And various types of hybrid kernels that do not fall precisely into one category. 

# Monolithic kernel
## What is the organization of a monolithic kernel? 
A **single binary image** contains all kernel functionality, and is always in memory. It has a single address space, which is shared between kernel components. 

Separate interfaced can be made, but are **not enforced by the kernel**. It relies on system programs to control the system. 

## Can a monolithic kernel be extended? How?
The single binary image is not extensible. To add new drivers, file systems, schedulers, etc., the system needs to either recompile the entire kernel and reboot, or use *loadable kernel modules* that are written against interfaces in the kernel and are (un)loaded during runtime. 

## What is the layered approach to monolithic kernels? 
The kernel can have abstract layers that rely on trap instructions to call function across layers. Each layer is based on a layer below it. 

## Does the layered approach have any effects on the implementation of the OS?
No; the kernel is still a **single binary image**! 
The layered approach is **only a design aid**. 

# Micro kernel 
## What is the main idea behind a micro kernel? 
In a *micro kernel system*, the kernel is as small as possible. 
As many components as possible are moved to user-space. 

## What functionality is provided by the kernel, and what is implemented in user space?
Kernel support: 
- inter-component communication 
- CPU register manipulation for enforcing protection & isolation
- context switches 
- handling interrups 

User-space: 
- process management 
- memory management 
- file management 
- device drivers 

## What are the advantages of using a micro kernel?
Advantages: 
- Easier to extend, no need for reboots. (Almost) everything can be written and started in user-space. 
- More reliable; crash in one component does not impact others 
- Easier to port; only needs to be done for micro kernel & device drivers 

## What are the disadvantages of using a micro kernel?
Disadvantages: 
- overhead because of message passing between components 
- overhead due to context switches between components 