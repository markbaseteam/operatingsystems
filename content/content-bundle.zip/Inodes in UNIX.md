---
aliases: [Inode, Inodes]
tags: [unix, os] 
date: 2022-04-09
---
%%
**Bron:** [The UNIX School: Inode - All about inodes](https://www.theunixschool.com/2011/06/inode-all-about-inodes.html)
%%
In UNIX, everything is a file. 
***

**Inodes store properties of a file** (size, owner, group, access, hard link count, etc). I.e. it contains all information of the file except the file name and the contents (data). 

**Inodes and I-node numbers are not the same.** The latter is an integer associated with a file. It is a unique integer number that uniquely points to the Inode structure containting properties of the file. 

**Mapping of Inode number with file name happens at directory level.** Any directory structure in UNIX maintains a table containing a list of file names with their Inode numbers.

This is different than using [[File Control Block]]s in every directory: 
![[file control block per directory vs inode.png]]