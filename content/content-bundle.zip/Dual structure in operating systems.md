---
aliases: [Dual structure, dual-mode operation]
tags: [os] 
date: 2022-02-11
---
***
# Dual structure
The OS relies on *dual-mode* operation: programs can run in either *user-mode* or *kernel-mode*. 

A *mode bit* (in the system register) is used to indicate the mode of current instruction. 

## How is hardware access controlled between user and kernel processes?
**The OS distinguishes between normal intructions and privileged instructions**; the latter can only be executed in kernel-mode. 

## How does the OS switch between modes?
In user-mode, an *[[Interrupt]]* is needed to return to kernel-mode. 

This can be a *hardware interrupt*, which is a programmable *timer controller* that returns control to kernel after a fixed time. It is used to escape infinitely looping programs by **guaranteeing that control is returned to the kernel after a fixed period**. 

A software interrupt is generated dynamically by user programs. It can be a fault of the program, like an error, zero-division, etc. It can also be a *[[System Call|system call request]]*, also known as a *trap mechanism* which is used for requesting privileged instructions from user-mode. 
![[System Call#What is a system call]]

## What is the difference between system and application programs?
The kernel is usually supported by other system programs. Some examples: 
- file system management: `ls`, `mv`, `mkdir`, etc
- acquiring system information 
- initialization and management of programs and system settings 
- background systems (*subsystems* or [[Deamons]])
- etc...

This means that the boundary between the actual kernel and the supporting programs is usually not very clear. 