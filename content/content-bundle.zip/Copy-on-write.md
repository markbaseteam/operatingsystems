---
aliases: [COW]
tags: [os]
date: 2022-03-24
---
***
# Copy-on-write
We hebben het al gehad over [[shared pages]]. **Deze techniek werkt alleen voor read-only pages**, want een proces kan niet zomaar schrijven naar een shared page — zelfs als het proces write permissions heeft. 

Een oplossing is om initieël dezelfde *rw-page* te delen tussen processen, zolang die niet wordt aangepast. Zodra een proces wil schrijven naar de page, kopieëren we het naar de address space van dat proces. Deze techniek heet *copy-on-write*. 

## Welke routine is nodig om copy-on-write te laten werken? 
De OS kernel moet nu een routine hebben die writes naar shared pages pakt: 
1. share page and give it read-only permission 
2. as soon as write is attempted, page fault
3. OS kernel receives control and creates copy of page for the process that requested a write

## Waarom is copy-on-write handig bij een fork? 
Als we `fork()` aanroepen, dan wordt het hele address space gekopieerd naar het nieuwe proces. Heel vaak wordt een fork direct gevolgd door een `execv()`, waardoor alle gekopieerde pagina's gelijk worden weggegooid. Copy-on-write voorkomt dit. 

 
