---
aliases: [Links to files]
tags: [os]
date: 2022-04-04
---
***
# Linking to files 
## Welke typen links naar files zijn er?
Een *symbolic link* is een directory entry type die een symbolische file name bevat van een *link target*. Deze pointer volgen heet dus "resolving the link". 
Als de link target verwijderd is, blijft de symbolic link bestaan zonder aangepast te worden. 

Een *hard link* is een duplicaat van een directory entry, die linkt naar *[[Inodes in UNIX|Inodes]]* die de daadwerkelijke file attributes opslaan. In de inode worden referenties naar een file bijgehouden, en pas als er geen referenties meer zijn, wordt het bestand verwijderd. 

Er kan ook via geheugen naar files worden gelinkt, met [[Memory-mapped files]]. 
***