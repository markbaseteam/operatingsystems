---
aliases: []
tags: [os] 
date: 2022-03-15
---
***
# Paging 
Paging is een belangrijk onderdeel van [[Virtual Memory]]. 
Bij paging is het geheugen opgedeeld in blokken van een vaste grootte. De notatie is *frames* of *physical pages* voor blokken in het fysieke geheugen, en *pages* of *virtual pages* in logisch geheugen. 

Een proces is contiguous op virtual pages, maar die liggen niet noodzakelijk contiguous in het fysieke geheugen. 

De problemen van [[#^b91e60|external fragmentation]] en contiguous memory allocation zijn opgelost, maar [[#^b91e60|external fragmentation]] is er nog steeds. 

Elk proces heeft een eigen virtual address space, en mag alleen pages daar in verkrijgen. Dit virtuele address space is mapped naar fysieke geheugen met een *page table*. De MMU voert nu een translatie van virtueel naar fysiek uit. 

Een adres bestaat nu uit 
- een page number $p$: vertaald via de page table
-  een page offset $d$: byte index in page, invariant onder translatie. 
  Page size bepaalt de verhouding grootte offset en index in een adres. 
  **De page size heet ook wel de 'granule'**. 

OS moet een lijst met beschikbare frames bijhouden zodat er snel een page aan een vrije frame kan worden toegewezen. 

Zie ook enkele geavanceerde paging techniques, zoals 
 - [[Translation Look-aside Buffer]] 
 - [[Types of Page table structures]]  
 - [[Memory swapping]] 