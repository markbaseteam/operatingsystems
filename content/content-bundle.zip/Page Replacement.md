---
aliases: [Page replacement algorithm]
tags: [os] 
date: 2022-03-24
---
Als de address space van een proces vol is, maar er toch nieuwe pages moeten worden toegevoegd, dan moeten we beslissen welke van de gealloceerde pages we weghalen. 
***
# Page replacement
Processen kunnen meer pagina's nodig hebben dan ze kregen op het moment dat ze startten. Als het geheugen vol is, kan dit niet, tenzij we oude pages weghalen. 

De kernel zoekt naar een page die kan worden vervangen middels een [[#Page replacement algorithms]]. 

Dit gaat op zoek naar een *victim page*. Als deze page geheugen bevat dat moet worden bewaard, dan kunnen we deze niet zo maar weggooien: 
- als de victim page een read-only page is die van de disk geladen werd, kunnen we die later weer laden 
- als het een rw-page is die nog niet is aangepast na de laatste load, dan kunnen we die ook later laden. (gebruik een *dirty bit* om aan te geven of naar een rw-page is geschreven)

## Page buffering 
We kunnen een pool met vrije frames bijhouden. Bij een page fault kunnen we direct naar een frame uit die pool schrijven. Pas als de faulting page is gealloceerd, kiezen we een victim page om te vervangen. Het frame wordt dan aan de pool gevoegd. 

Een andere manier om prestaties te verbeteren is het naar disk schrijven van modified pages als het systeem idle is. Dat hoeft dan niet meer te worden gedaan als deze pages als victim worden gekozen, wanneer het systeem niet idle is. 

## RW pages en page replacement 
Als een proces een write request doet via I/O, dan kan het zijn dat bij het wachten op I/O de page al verwisseld zou zijn. Dat is natuurlijk niet de bedoeling, dus daarom **kan de kernel page pinning toepassen om page replacement te voorkomen**.  

# Page replacement algorithms 
Om page replacement algorithms te beoordelen, kijken we naar het toepassen van een algoritme op een reference-string van geheugen accesses. We vergelijken dan het aantal page faults, ervanuitgaande dat we 3 frames hebben. 

## Optimal (OPT)
Dit algoritme wisselt de page die het langste niet gaat worden gebruikt. 
![[optimal page replacement.png|500]]
Dit is natuurlijk **onmogelijk te implementeren**. 

## First in, First out (FIFO)
Heel simpel, maar slechte resultaten. Er vinden 15 page faults plaats.
![[fifo page replacement.png|500]]
Dit algoritme maakt geen onderscheid tussen hoe vaak pages worden aangesproken. 

Een ander probleem is [[Belady's anomaly]], waarbij we zelfs met een groter aantal frames geen garantie hebben om betere resultaten te krijgen. Sterker nog, de resultaten kunnen zelfs slechter worden. 

## Least recently used (LRU)
Dit algoritme wordt ook gebruikt voor caching. 
> *“If you want to know the future, look at the past.”*
> ~Joe Biden

Er vinden 12 page faults plaats. 
![[LRU page replacement.png|500]]

Maar implementatie is moeilijk. We moeten pages op tijd ordenen. Dit kan op twee manieren. 
1. *Counter based*: CPU maintains counter on each memory access, and writes to page table entry. **This is very costly**: 
	- We moeten counter waardes kopiëren naar de page table
	- We moeten zoeken naar de hoogste page entry in de page table 
2. *Stack based*: we houden een stapel van page nummers bij, en het onderste element is de LRU page. Dit is nog steeds duur: 
	- Stack operaties voor updates zijn duur. 

 Conclusie: **beide manieren van LRU zijn te duur**. 

## LRU approximation 
Veel computerchitecturen hebben een *reference bit* in de page table entry die 1 wordt als er een referentie naar de page is. 
De kernel kan zien welke pages in een interval zijn gebruikt, maar binnen dat interval is de volgorde niet te onderscheiden. 

We kunnen meer informatie opslaan door op vaste tijden reference bits toe te voegen aan een *shift-register*. Dit is bekend als het *additional-reference-bits algorithm*. 
Het is erg duur, dus veel architecturen gebruiken nog steeds een enkele reference bit.  ^34dd9d

## Second chance algorithm
Dit is effectief het [[#^34dd9d|additional-reference-bits]] algorithm, maar met een enkele reference bit. 

We gebruiken [[#First in First out FIFO|FIFO]] om een page te kiezen binnen een **circulaire linked list**. Als de victim page een reference bit van 0 heeft, dan vervangen we die. Als er een 1 is, dan zetten we die naar 0, en gaan we door met zoeken in de lijst naar een page met een reference bit van 0. 

![[second chance page replacement.png|500]]

We kunnen ook de *dirty-bit* gebruiken van de page table. Omdat pages die nog niet zijn aangepast ook goedkoper zijn om te vervangen, is het handiger die te kiezen. 
We gaan dan dus op zoek naar $(00),(01),(10),(11)$ van tuples *(recently used, modified)*. 
