---
aliases: [raid, redundant array of inexpensive disks, redundant array of independent disks]
tags: [os] 
date: 2022-05-12
---
***
# RAID systems 
"Redundant array of independent disks" 

Why?
- Redundancy of data 
- Performance, parallel reads/writes
- Larger drives (e.g. 140Tb file system is possible, but not on a single disk)

## Hardware 
RAID can be done through software, but separate hardware cards are common for server systems. 

The RAID configuration is stored in BIOS of raid card.  The OS accesses the RAID card and sees the 'combined' drives as configured in the card. The RAID card contains CPU for small calculations, e.g. about [[Parity in RAID]]. 

Some raid cards have a battery or use [[Non-Volatile Storage|NVM]] to store intermediate buffers, to allow write-back (cf. [[Comparing cache architectures#Write back]]). This also protects buffered data in case of power failure (like [[journaling file systems]]). 

## RAID levels 
Most 'levels' based on *block striping*: data is striped in blocks of e.g. 64KiB. 

See this visual for overview of raid levels: 
![[visual different levels of RAID.png|400]]

### RAID0
Data is striped by alternating between disks. 
This is **not redundant!**—but, it increases bandwidth.

Used for e.g. video editing setups, where redundancy is implemented independent of RAID, i.e. original file is stored somewhere else in case of disk failure. 

### RAID1 
Each stripe stored on *all* disks in set; 'mirrored stripes'. 
Then if one disk fails, no data is lost. 

Variants exist such as *mirrored declustering*, in which case $N$ disks are turned into $N/2$ mirrors, and data is striped over these mirrors. This is essentially RAID1+0, see [[#Combined levels]].

In linux, the RAID1 implementation writes to all $N$ disks of an $N$ disk array. 

### RAID2 
Bit-level striping, also through ECC. 
Not commonly used.

### RAID3
Byte-level striping; means that disks have to spin in sync. 
Also not commonly used.

### RAID4 
Striping with separated and dedicated *parity disk*. 
Any disk in setup can be lost (but only one), and contents can be rebuild from other disks. 
The parity disk is used most often, and therefore most likely to fail. 

### RAID5 
Same as RAID4, but parity distributed over all disks instead of a single parity disk. Now no single disk is more likely to fail, because the load is distributed uniformly. 

### RAID6 
Two parity blocks instead of one: *two* disks can fail instead of one. 

Also *multidimensional RAID6*: more than two parity drives; arrange drives in 2-d grid. 

### Combined levels
Sometimes 1 and 0 are combined; 
- RAID01 is mirror of striped sets
- RAID10 is striping over mirrors 

High performance *and* redundancy, at cost of more disks. 
RAID10 advised for DBMS

See this visual: 
![[Screenshot_20210420_143114.png|400]]


## What happens on disk failure?
On disk failure: 
1. controller detects failure, notifies responsible parties 
2. broken disk must be replaced; once done a rebuild is started. 
  Contents of old disk reconstruced by reading other disks. 
  
What if other disk fails during rebuild?
- RAID5: all data on that disk lost 
- RAID6: no problem until additional disk fails 

Rebuild must happen ASAP, often an installed but unused disk (*hot spare disk*) is used. This will automatically take over after failure. 

## Is RAID a backup? 
> [!warning] RAID is not a backup!
> An array may still fail. A building may still burn. File system may still be corrupted.  
Backups to other storage devices remain important.

