---
aliases: []
tags: [os]
date: 2022-04-04
---
***
Als meerdere processen op een file willen opereren, kunnen ze de file locken. Er is een *shared lock* als alle processen die een lock op de file krijgen, er op mogen opereren. Er is een een *exclusive lock* als een enkel proces exclusieve toegang krijgt. 

Sommige OSen implementeren *mandatory locking*, waarbij het OS de locks en respectieve operatieverzoeken handhaaft. Anderen hebben *advisory locking*, waarbij processen kunnen vragen wat de lock-toestand is, en dan zelf beslissen wat ze doen. 
***