---
aliases: [HDD Scheduling]
tags: [os] 
date: 2022-05-12
---
***
# Hard disk scheduling 
Disk I/O performance can be measured and improved: 
- *Access time*: from request to first block of requested data available (closely related to *seek time*). 
- *Disk bandwidth*: total number of bytes transferred over the time from the first request and completion of last I/O transfer. 

## Improving access time
Access time depends on seek time, which depends on seek distance. We need to minimize seek distance. 

On personal devices, the disk is often idle, and requests can be sent to disk immediately. Not much optimizing possible. 

Server systems are often I/O bound. Requests (from transactions) are received and executed in parallel. We get a queue of requests competing for disk access. 

We can optimize speed by choosing which requests to prioritize: choose requests in order to minimze seek time. This is known as *hdd scheduling*. 

# Algorithms
Algorithms are compared in a simple example: 
- disk with cylinders $0-199$
- request queue with requests $98, 183, 37, 122, 14, 124, 65, 67$
- initial head position of $53$

## First come, first serve 
Known as FCFS. Not good.

## Shortest seek time first 
Known as SSTF. 
The scheduler scans the queue for requests with the shortest seek distance from the current head position. 

This is a lot better than FCFS, however, starvation can occur. **Starvation occurs when the head stays in some 'hot' region and postpones requests further away indefinitely.** 

## SCAN
Also known as the *elevator algorithm*. 
Handle all requests in one direction until end of disk, then move the other way around. 

### C-SCAN 
However, this might again lead to starvation. **If a request appears just after the head has passed the location, it needs to handle all requests in both directions before handling the new request.** 
A way to mitigate this is to use circular movement instead of zig-zag: *circular*-scan. 

### (C)LOOK
LOOK and C-LOOK are variants of the SCAN algorithm, where the head will not move until the end of the disk, but rather the outermost current requests. 

# Choosing an algorithm
For heavy loads, SCAN and C-SCAN perform well. 
Other considerations: 
- How are disk blocks allocated on OS level? E.g. contiguous results in faster reads. 
- Optimizing for rotational latency is hard, does OS always know current head position? 
- Disk itself might also implement request queuing, is OS queuing not negated? 