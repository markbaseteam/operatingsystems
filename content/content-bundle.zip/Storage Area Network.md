---
aliases: [SAN]
tags: [OS]
date: 2022-05-12
---
***
# Storage area networks 
This method only seen in large enterprise deployments. 

Storage devices (arrays of hard disks, tape robots) connected to dedicated network. Servers also connected to this network. 

Mappings between server and storage device can be dynamic; e.g. when server fails, another server starts to access same storage device 
***