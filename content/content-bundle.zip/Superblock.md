---
aliases: [Volume control block]
tags: [os]
date: 2022-04-19
---
***
Bij het [[Mounting|mounten]] van een bestandssysteem worden een partitie, en *mountpoint* aangegeven. Als we willen weten welk bestandssysteem deze partitie heeft, kijken we naar het *magic number*. 

Zodra we dit weten kunnen we de juiste driver gebruiken om het bestandssysteem te openen. De driver moet dingen weten: 
- hoe groot is bestandssyteem
- hoe groot zijn diskblokken
- file system identifier (het magic number)
- pointer naar root directory 
- waar is het begin van het bestandssysteem
- wat is de exit status van de vorige keer 

Dit alles staat in het *superblock*, ook wel bekend als *volume control block*. 
***