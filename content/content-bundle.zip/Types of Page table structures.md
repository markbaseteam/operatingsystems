---
aliases: [Hierarchical page table, hashed page table, inverted page table]
tags: [os] 
date: 2021-03-08
---
***
# Page table structure 
## Kunnen we pages in een flat hierarchy opslaan?
We kunnen niet alle pages opslaan in geheugen zonder slimme trucjes. 
Stel je hebt een 32-bit address space, met pages van 4 KiB ($2^{12}$ bits). 
Dan zijn er dus $2^{20}$ pages, die elk een 4-bit descriptor nodig hebben, dus moet de page table $4 \cdot 2^{20} = 4$ MiB **per proces**. 

## Hoe helpen hierarchical page tables met ruimte besparen?
Hierarchical page tables zijn een multi-level tree. Stel dat we 20-bit page nummer hebben, die in 2 10-bit delen wordt gedeeld. Dan gebruiken we de eerste 10 bits als index voor de first-level page table, en de tweede 10 bits als index voor de second-level page table.  

Dit kunnen we uitbreiden naar meerdere niveaus. Sterker nog, bij een 64-bit address space is een enkele outer page table te groot. Daarom is bij moderne systemen een adres opgedeeld in 3 of 4 delen.
E.g. 2nd outer page $p_1$ is de eerste 32 bits, daarna outer page $p_2$ en inner page $p_{3}$ elk 10 bits, en de offset $d$ is de laatste 12 bits. 

Het nadeel is dus wel dat er voor elke enkele memory access *meerdere* accesses moeten plaatsvinden om te vertalen naar een fysiek adres. Daarom gebruiken we dus de [[#Translation Look-aside buffer]].  

## Hashed page tables 
 #Todo/Onderzoeken 

## Inverted page tables 
 #Todo/Onderzoeken 
