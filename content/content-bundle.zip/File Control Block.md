---
aliases: [FCB, FCBs]
tags: [os] 
date: 2022-04-10
---
***
# File control block
Dit slaat metadata van bestanden op. 

## Wat staat er in de FCB?
De indeling hangt af van verschillende dingen: 
- is het een complete FCB per directory, of wijst elke directory naar een [[Inodes in UNIX|Inode]] table ergens? 
- Hoe doen we [[Mapping files to fysical disk blocks|Bestanden afbeelden op diskblokken]]? 
	- Bij *Indexed Allocation* moet de FCB een link naar een indexblok bevatten 
	- Bij *Combined Scheme* staan er [[Mapping files to fysical disk blocks#Combined scheme|veel fields bij elke filename]] 
- 

## Directory vs Inode FCB 
### Directory
Dit kan per directory, met de metadata naast de filename in tuples (a in figuur). Dan staan er in de lijst 
- filename 
- associated FCB 

Dus de FCB pointer wijst naar een file met data, of een directory met een nieuwe eigen FCB. 
![[directory based fcb.png|400]]

### Inode 
Het kan ook door een centrale tabel te hebben die wijst naar de unieke nummers (*Inode-nummers*) van directory-specifieke FCBs (b in figuur). In dit geval heten die FCBs [[Inodes in UNIX|Inodes]]. 
Meerdere filenames kunnen hetzelfde inode number hebben, dus hebben ze dezelfde attributen en data. 

  ![[inode based fcb.png|380]]